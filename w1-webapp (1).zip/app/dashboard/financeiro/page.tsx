import EmConstrucao from "../em-construcao"

export default function FinanceiroPage() {
  return (
    <EmConstrucao
      titulo="Módulo Financeiro em Desenvolvimento"
      descricao="Estamos trabalhando para disponibilizar o módulo financeiro completo em breve. Você receberá uma notificação quando estiver pronto."
      voltarPara={{
        texto: "Voltar para o Dashboard",
        link: "/dashboard",
      }}
    />
  )
}
