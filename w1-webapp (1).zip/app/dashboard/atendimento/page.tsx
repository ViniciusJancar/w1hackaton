import type { Metadata } from "next"
import { Headphones, Bot, Clock, Users, MessageSquare } from "lucide-react"

import { AssistenteChatbot } from "@/components/assistente-chatbot"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Atendimento | W1 Holding Patrimonial",
  description:
    "Central de atendimento automatizado com IA para tirar suas dúvidas sobre o processo de constituição de holding patrimonial.",
}

export default function AtendimentoPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold tracking-tight">Atendimento</h1>
          <Badge variant="outline" className="bg-primary/10 text-primary">
            <Bot className="mr-1 h-3 w-3" />
            Com IA
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Headphones className="h-5 w-5" />
          <span className="text-sm">Central de Atendimento Automatizado</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <AssistenteChatbot />
        </div>

        <div className="lg:col-span-1">
          <Card className="h-full border-2 border-gray-700 bg-gray-800 shadow-lg text-gray-100">
            <CardHeader className="border-b border-gray-700">
              <CardTitle className="text-xl">Precisa de ajuda?</CardTitle>
              <CardDescription className="text-gray-400">
                Nossos especialistas estão disponíveis para atendê-lo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 py-4">
              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-700 bg-gray-700/50">
                <div className="bg-primary/10 p-2 rounded-full">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Horário de Atendimento</h3>
                  <p className="text-sm text-gray-400">Segunda a Sexta, das 9h às 18h</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-700 bg-gray-700/50">
                <div className="bg-primary/10 p-2 rounded-full">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Equipe Especializada</h3>
                  <p className="text-sm text-gray-400">Advogados e consultores tributários à sua disposição</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-700 bg-gray-700/50">
                <div className="bg-primary/10 p-2 rounded-full">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Contato Direto</h3>
                  <p className="text-sm text-gray-400">Telefone: (11) 3456-7890</p>
                  <p className="text-sm text-gray-400">Email: atendimento@w1holding.com.br</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                variant="outline"
                className="border-gray-600 bg-gray-700 hover:bg-gray-600 text-gray-100"
              >
                Agendar Reunião
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
