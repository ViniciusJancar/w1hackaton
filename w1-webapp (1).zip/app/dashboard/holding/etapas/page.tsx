const EtapasPage = () => {
  return (
    <div className="container mx-auto p-2 sm:p-4">
      <h1 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-4">Etapas do Projeto</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
        {/* Card 1 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 1: Planejamento</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">
            Definição dos objetivos, escopo e recursos necessários.
          </p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-teal-500 h-2 rounded-full" style={{ width: "75%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">75%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-teal-100 text-teal-800 border border-teal-200">
              Concluído
            </span>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 2: Desenvolvimento</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">Implementação das funcionalidades e testes iniciais.</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: "40%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">40%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
              Em Andamento
            </span>
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 3: Testes e Validação</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">
            Realização de testes abrangentes e validação dos resultados.
          </p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-amber-500 h-2 rounded-full" style={{ width: "10%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">10%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
              Pendente
            </span>
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 4: Implantação</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">Colocação em produção e monitoramento inicial.</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-amber-500 h-2 rounded-full" style={{ width: "0%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">0%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800 border border-amber-200">
              Pendente
            </span>
          </div>
        </div>

        {/* Card 5 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 5: Manutenção</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">Correções e melhorias contínuas.</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: "20%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">20%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
              Em Andamento
            </span>
          </div>
        </div>

        {/* Card 6 */}
        <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow p-3 sm:p-4">
          <h2 className="text-base sm:text-lg font-semibold text-gray-800 mb-2">Etapa 6: Documentação</h2>
          <p className="text-xs sm:text-sm text-gray-600 mb-3">Criação de documentação detalhada.</p>
          <div className="flex items-center justify-between mt-4">
            <span className="text-xs sm:text-sm text-gray-500">Progresso:</span>
            <div className="w-1/2 sm:w-2/3 bg-gray-200 rounded-full h-2">
              <div className="bg-teal-500 h-2 rounded-full" style={{ width: "100%" }}></div>
            </div>
            <span className="text-xs sm:text-sm text-gray-500">100%</span>
          </div>
          <div className="mt-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-teal-100 text-teal-800 border border-teal-200">
              Concluído
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EtapasPage
