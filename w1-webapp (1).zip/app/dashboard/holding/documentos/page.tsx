import { FileText, Upload, Search, Download, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DocumentosHolding() {
  // Dados de exemplo para documentos
  const documentos = [
    {
      id: 1,
      nome: "Contrato Social - Minuta",
      categoria: "Documentos Societários",
      etapa: "Elaboração do Contrato Social",
      data: "10/05/2023",
      status: "Em análise",
      statusColor: "amber",
    },
    {
      id: 2,
      nome: "Análise Patrimonial Completa",
      categoria: "Análises",
      etapa: "Análise do Patrimônio",
      data: "05/05/2023",
      status: "Aprovado",
      statusColor: "teal",
    },
    {
      id: 3,
      nome: "Planejamento Sucessório",
      categoria: "Planejamento",
      etapa: "Planejamento Inicial",
      data: "01/05/2023",
      status: "Aprovado",
      statusColor: "teal",
    },
    {
      id: 4,
      nome: "Certidão de Imóvel - Apartamento",
      categoria: "Documentos Pessoais",
      etapa: "Análise do Patrimônio",
      data: "28/04/2023",
      status: "Aprovado",
      statusColor: "teal",
    },
    {
      id: 5,
      nome: "Certidão de Imóvel - Casa de Praia",
      categoria: "Documentos Pessoais",
      etapa: "Análise do Patrimônio",
      data: "28/04/2023",
      status: "Pendente de informações",
      statusColor: "red",
    },
    {
      id: 6,
      nome: "Proposta de Estrutura Jurídica",
      categoria: "Documentos Societários",
      etapa: "Escolha da Estrutura Jurídica",
      data: "15/04/2023",
      status: "Aguardando revisão",
      statusColor: "blue",
    },
  ]

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Documentos da Holding</h1>
          <p className="mt-2 text-xl text-gray-600">
            Gerencie todos os documentos relacionados à sua holding patrimonial
          </p>
        </div>
        <div className="mt-4 flex space-x-3 md:mt-0">
          <Button className="bg-teal-500 text-white hover:bg-teal-600">
            <Upload className="mr-2 h-4 w-4" />
            Enviar Documento
          </Button>
        </div>
      </div>

      <div className="rounded-xl bg-white p-6 shadow-md border border-gray-200">
        <Tabs defaultValue="todos" className="w-full">
          <div className="mb-6 flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
            <TabsList className="bg-gray-100">
              <TabsTrigger value="todos" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
                Todos
              </TabsTrigger>
              <TabsTrigger value="pendentes" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
                Pendentes
              </TabsTrigger>
              <TabsTrigger value="aprovados" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
                Aprovados
              </TabsTrigger>
              <TabsTrigger value="analise" className="data-[state=active]:bg-teal-500 data-[state=active]:text-white">
                Em Análise
              </TabsTrigger>
            </TabsList>

            <div className="flex flex-col space-y-2 md:flex-row md:space-x-2 md:space-y-0">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Buscar documentos"
                  className="pl-9 bg-white border-gray-300 text-gray-800 placeholder:text-gray-400 focus-visible:ring-teal-500"
                />
              </div>
              <Select>
                <SelectTrigger className="w-full md:w-[180px] bg-white border-gray-300 text-gray-800">
                  <SelectValue placeholder="Filtrar por etapa" />
                </SelectTrigger>
                <SelectContent className="bg-white border-gray-200 text-gray-800">
                  <SelectItem value="todas">Todas as etapas</SelectItem>
                  <SelectItem value="planejamento">Planejamento Inicial</SelectItem>
                  <SelectItem value="analise">Análise do Patrimônio</SelectItem>
                  <SelectItem value="estrutura">Escolha da Estrutura</SelectItem>
                  <SelectItem value="contrato">Elaboração do Contrato</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <TabsContent value="todos" className="mt-0">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-gray-200 text-left">
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Nome do Documento</th>
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Categoria</th>
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Etapa</th>
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Data</th>
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Status</th>
                    <th className="pb-3 pt-6 text-sm font-medium text-gray-600">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {documentos.map((doc) => (
                    <tr key={doc.id} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="py-4">
                        <div className="flex items-center">
                          <div className="mr-3 rounded-md bg-gray-100 p-2">
                            <FileText className="h-5 w-5 text-gray-600" />
                          </div>
                          <span className="font-medium text-gray-800">{doc.nome}</span>
                        </div>
                      </td>
                      <td className="py-4 text-gray-700">{doc.categoria}</td>
                      <td className="py-4 text-gray-700">{doc.etapa}</td>
                      <td className="py-4 text-gray-700">{doc.data}</td>
                      <td className="py-4">
                        <span
                          className={`inline-flex items-center rounded-full bg-${doc.statusColor}-100 px-2.5 py-0.5 text-xs font-medium text-${doc.statusColor}-700`}
                        >
                          {doc.status}
                        </span>
                      </td>
                      <td className="py-4">
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-700">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-700">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="pendentes" className="mt-0">
            <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-center">
              <p className="text-lg text-red-700">Você tem 1 documento pendente que requer sua atenção.</p>
              <Button className="mt-4 bg-red-500 text-white hover:bg-red-600">Resolver Pendência</Button>
            </div>
          </TabsContent>

          <TabsContent value="aprovados" className="mt-0">
            <div className="rounded-lg border border-teal-200 bg-teal-50 p-4 text-center">
              <p className="text-lg text-teal-700">
                Todos os seus documentos aprovados estão disponíveis para visualização.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="analise" className="mt-0">
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-center">
              <p className="text-lg text-amber-700">
                Seus documentos estão sendo analisados pela nossa equipe jurídica.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
