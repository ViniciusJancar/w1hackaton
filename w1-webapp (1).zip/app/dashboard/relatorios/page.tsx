import EmConstrucao from "../em-construcao"

export default function RelatoriosPage() {
  return (
    <EmConstrucao
      titulo="Relatórios em Desenvolvimento"
      descricao="Estamos implementando relatórios detalhados e personalizáveis para sua empresa. Esta funcionalidade estará disponível em breve."
      voltarPara={{
        texto: "Voltar para o Dashboard",
        link: "/dashboard",
      }}
    />
  )
}
