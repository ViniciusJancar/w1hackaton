import EmConstrucao from "../em-construcao"

export default function ConfiguracoesPage() {
  return (
    <EmConstrucao
      titulo="Configurações em Desenvolvimento"
      descricao="O painel de configurações está sendo implementado. Em breve você poderá personalizar sua experiência na plataforma."
      voltarPara={{
        texto: "Voltar para o Dashboard",
        link: "/dashboard",
      }}
    />
  )
}
