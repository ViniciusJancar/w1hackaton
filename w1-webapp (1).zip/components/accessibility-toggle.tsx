"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Accessibility } from "lucide-react"
import { useLocalStorage } from "@/hooks/use-local-storage"

export function AccessibilityToggle() {
  const [mounted, setMounted] = useState(false)
  const [accessibilityMode, setAccessibilityMode] = useLocalStorage<boolean>("accessibility-mode", false)

  useEffect(() => {
    setMounted(true)

    // Aplicar classes de acessibilidade ao documento
    if (accessibilityMode) {
      document.documentElement.classList.add("accessibility-mode")
    } else {
      document.documentElement.classList.remove("accessibility-mode")
    }
  }, [accessibilityMode])

  if (!mounted) return null

  return (
    <Button
      variant="outline"
      size="lg"
      className="fixed bottom-4 left-4 z-50 bg-gray-800 text-white hover:bg-gray-700 rounded-full shadow-lg p-3 h-auto"
      onClick={() => setAccessibilityMode(!accessibilityMode)}
      title={accessibilityMode ? "Desativar modo de acessibilidade" : "Ativar modo de acessibilidade"}
    >
      <Accessibility className="h-6 w-6" />
      <span className="sr-only">
        {accessibilityMode ? "Desativar modo de acessibilidade" : "Ativar modo de acessibilidade"}
      </span>
    </Button>
  )
}
