"use client"

import type React from "react"

import { useState } from "react"
import Link, { type LinkProps } from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

interface SafeLinkProps extends LinkProps {
  children: React.ReactNode
  className?: string
  activeClassName?: string
  pendingClassName?: string
  inConstruction?: boolean
}

export function SafeLink({
  children,
  className,
  activeClassName,
  pendingClassName,
  inConstruction = false,
  ...props
}: SafeLinkProps) {
  const pathname = usePathname()
  const [isPending, setIsPending] = useState(false)

  const isActive = pathname === props.href

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    // Se está em construção, evite a navegação padrão
    if (inConstruction) {
      e.preventDefault()
      setIsPending(true)

      // Simula um tempo de carregamento antes de mostrar a mensagem
      setTimeout(() => {
        setIsPending(false)
        alert("Esta funcionalidade está em desenvolvimento e estará disponível em breve.")
      }, 300)
    }
  }

  return (
    <Link
      className={cn(className, isActive && activeClassName, isPending && pendingClassName)}
      onClick={handleClick}
      {...props}
    >
      {children}
    </Link>
  )
}
