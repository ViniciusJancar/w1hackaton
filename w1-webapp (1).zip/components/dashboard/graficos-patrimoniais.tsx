"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

// Paleta de cores com ordem de prioridade ajustada
const COLORS = {
  primary: "#009E73", // Verde (principal)
  secondary: "#56B4E9", // Azul claro (secundária)
  tertiary: "#E69F00", // Laranja (terciária)
  quaternary: "#F0E442", // Amarelo (quaternária)
  quinary: "#333333", // Cinza escuro (quinta)
  senary: "#CC79A7", // Rosa (sexta)
  darkBlue: "#0072B2", // Azul escuro (alternativa)
  darkOrange: "#D55E00", // Laranja escuro (alternativa)
  gray: "#999999", // Cinza (alternativa)
}

export function GraficosPatrimoniais({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={className} {...props}>
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-gray-800">Evolução Patrimonial</CardTitle>
            <CardDescription className="text-gray-600">Crescimento do patrimônio nos últimos 5 anos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={[
                    { ano: "2018", valor: 2800000 },
                    { ano: "2019", valor: 3100000 },
                    { ano: "2020", valor: 3400000 },
                    { ano: "2021", valor: 3850000 },
                    { ano: "2022", valor: 4200000 },
                    { ano: "2023", valor: 4500000 },
                  ]}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="ano" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" tickFormatter={(value) => `${(value / 1000000).toFixed(1)}M`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB", borderRadius: "0.375rem" }}
                    itemStyle={{ color: "#1F2937" }}
                    formatter={(value: number) => [`R$ ${value.toLocaleString()}`, "Patrimônio"]}
                  />
                  <Area
                    type="monotone"
                    dataKey="valor"
                    name="Patrimônio"
                    stroke={COLORS.primary}
                    fill={COLORS.primary}
                    fillOpacity={0.3}
                    activeDot={{ r: 8 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all duration-300">
          <CardHeader>
            <CardTitle className="text-lg font-medium text-gray-800">Distribuição por Tipo de Ativo</CardTitle>
            <CardDescription className="text-gray-600">Composição atual do patrimônio</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: "Imóveis", valor: 65, color: COLORS.primary },
                      { name: "Investimentos", valor: 20, color: COLORS.secondary },
                      { name: "Participações", valor: 10, color: COLORS.tertiary },
                      { name: "Outros", valor: 5, color: COLORS.quaternary },
                    ]}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="valor"
                    label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }) => {
                      const RADIAN = Math.PI / 180
                      const radius = innerRadius + (outerRadius - innerRadius) * 0.5
                      const x = cx + radius * Math.cos(-midAngle * RADIAN)
                      const y = cy + radius * Math.sin(-midAngle * RADIAN)

                      return (
                        <text
                          x={x}
                          y={y}
                          fill="white"
                          textAnchor={x > cx ? "start" : "end"}
                          dominantBaseline="central"
                          fontWeight="bold"
                        >
                          {`${(percent * 100).toFixed(0)}%`}
                        </text>
                      )
                    }}
                  >
                    {[
                      { name: "Imóveis", valor: 65, color: COLORS.primary },
                      { name: "Investimentos", valor: 20, color: COLORS.secondary },
                      { name: "Participações", valor: 10, color: COLORS.tertiary },
                      { name: "Outros", valor: 5, color: COLORS.quaternary },
                    ].map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB", borderRadius: "0.375rem" }}
                    itemStyle={{ color: "#1F2937" }}
                    formatter={(value: number) => [`${value}%`, "Percentual"]}
                  />
                  <Legend
                    layout="horizontal"
                    verticalAlign="bottom"
                    align="center"
                    formatter={(value, entry, index) => <span style={{ color: "#1F2937" }}>{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
