"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Briefcase,
  CreditCard,
  FileText,
  LayoutDashboard,
  LogOut,
  Settings,
  Users,
  Home,
  Headphones,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { SafeLink } from "@/components/safe-link"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"

interface SubMenuItem {
  title: string
  href: string
}

interface MenuItem {
  title: string
  href: string
  icon: React.ElementType
  submenu?: SubMenuItem[]
  alwaysShowSubmenu?: boolean
}

const menuItems: MenuItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
    alwaysShowSubmenu: true, // Sempre mostrar submenu
    submenu: [
      {
        title: "Visão Geral",
        href: "/dashboard",
      },
      {
        title: "Análise Financeira",
        href: "/dashboard/analise-financeira",
      },
      {
        title: "Mapa de Riscos",
        href: "/dashboard/mapa-riscos",
      },
    ],
  },
  {
    title: "Holding Patrimonial",
    href: "/dashboard/holding",
    icon: Briefcase,
    submenu: [
      {
        title: "Visão Geral",
        href: "/dashboard/holding",
      },
      {
        title: "Documentos",
        href: "/dashboard/holding/documentos",
      },
      {
        title: "Processo",
        href: "/dashboard/holding/etapas",
      },
    ],
  },
  {
    title: "Atendimento",
    href: "/dashboard/atendimento",
    icon: Headphones,
  },
  {
    title: "Financeiro",
    href: "/dashboard/financeiro",
    icon: BarChart3,
  },
  {
    title: "Transações",
    href: "/dashboard/transacoes",
    icon: CreditCard,
  },
  {
    title: "Relatórios",
    href: "/dashboard/relatorios",
    icon: FileText,
  },
  {
    title: "Equipe",
    href: "/dashboard/equipe",
    icon: Users,
  },
  {
    title: "Configurações",
    href: "/dashboard/configuracoes",
    icon: Settings,
  },
]

// Páginas em construção
const pagesInConstruction = [
  "/dashboard/financeiro",
  "/dashboard/transacoes",
  "/dashboard/relatorios",
  "/dashboard/equipe",
  "/dashboard/configuracoes",
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const { logout } = useAuth()
  const router = useRouter()

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  if (!mounted) return null

  // Função para verificar se um item principal está ativo
  const isMainItemActive = (item: MenuItem): boolean => {
    // Se tem submenu, verifica se algum subitem está ativo
    if (item.submenu && item.submenu.length > 0) {
      return item.submenu.some((subItem) => {
        if (subItem.href === "/dashboard" && pathname === "/dashboard") {
          return true
        }
        if (subItem.href !== "/dashboard" && pathname.startsWith(subItem.href)) {
          return true
        }
        return false
      })
    }

    // Se não tem submenu, verifica diretamente
    if (item.href === "/dashboard" && pathname === "/dashboard") {
      return true
    }
    if (item.href !== "/dashboard" && pathname.startsWith(item.href)) {
      return true
    }

    return false
  }

  // Função para verificar se um subitem está ativo
  const isSubItemActive = (subItem: SubMenuItem): boolean => {
    // Caso especial para a página inicial do dashboard
    if (subItem.href === "/dashboard" && pathname === "/dashboard") {
      return true
    }

    // Para outros subitens, verificamos se o pathname corresponde EXATAMENTE ao href
    // ou começa com o href seguido por uma barra (para evitar correspondências parciais)
    if (subItem.href !== "/dashboard") {
      return (
        pathname === subItem.href ||
        pathname === `${subItem.href}/` ||
        (pathname.startsWith(`${subItem.href}/`) && !pathname.includes("/etapas/"))
      )
    }

    return false
  }

  return (
    <aside className="fixed inset-y-0 left-0 z-10 hidden w-64 flex-col bg-white border-r border-border md:flex shadow-sm">
      {/* Header do Sidebar */}
      <div className="flex h-16 items-center px-6 border-b border-border">
        <Link href="/dashboard" className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 72 36"
            height="36"
            width="72"
            className="mr-2"
          >
            <g clipPath="url(#clip0_2635_2144)">
              <path
                fill="#374151"
                d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
              ></path>
            </g>
            <defs>
              <clipPath id="clip0_2635_2144">
                <rect fill="white" height="36" width="72"></rect>
              </clipPath>
            </defs>
          </svg>
        </Link>
      </div>

      {/* Link para voltar ao site */}
      <div className="mt-6 px-4">
        <Link
          href="/"
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-black transition-colors rounded-lg hover:bg-gray-100"
        >
          <Home className="h-4 w-4" />
          <span>Voltar ao site</span>
        </Link>
      </div>

      {/* Título do menu */}
      <div className="mt-2 px-4">
        <h2 className="px-3 text-xs font-semibold text-black uppercase tracking-wider">Menu Principal</h2>
      </div>

      {/* Navegação principal */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        {menuItems.map((item) => {
          const isMainActive = isMainItemActive(item)
          const isInConstruction = pagesInConstruction.includes(item.href)
          const hasSubmenu = item.submenu && item.submenu.length > 0
          const showSubmenu = hasSubmenu && (isMainActive || item.alwaysShowSubmenu)

          return (
            <div key={item.href} className="space-y-1">
              {/* Item principal */}
              {isInConstruction ? (
                <SafeLink
                  href={item.href}
                  inConstruction={true}
                  className={cn(
                    "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 ease-in-out",
                    isMainActive
                      ? "bg-primary/10 text-primary font-bold border-l-4 border-primary"
                      : "text-black hover:bg-gray-100",
                  )}
                >
                  <div className="flex items-center">
                    <item.icon
                      className={cn("mr-3 h-5 w-5 transition-colors", isMainActive ? "text-primary" : "text-gray-600")}
                    />
                    <span>{item.title}</span>
                  </div>
                  {isMainActive && <div className="h-2 w-2 rounded-full bg-primary" />}
                </SafeLink>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 ease-in-out",
                    isMainActive
                      ? "bg-primary/10 text-primary font-bold border-l-4 border-primary"
                      : "text-black hover:bg-gray-100",
                  )}
                >
                  <div className="flex items-center">
                    <item.icon
                      className={cn("mr-3 h-5 w-5 transition-colors", isMainActive ? "text-primary" : "text-gray-600")}
                    />
                    <span>{item.title}</span>
                  </div>
                  {isMainActive && <div className="h-2 w-2 rounded-full bg-primary" />}
                </Link>
              )}

              {/* Submenu */}
              {showSubmenu && (
                <div className="ml-9 space-y-1 border-l-2 border-primary/20 pl-3">
                  {item.submenu!.map((subItem) => {
                    const isSubActive = isSubItemActive(subItem)
                    const isSubInConstruction = subItem.href.includes("/dashboard/holding/processo")

                    return isSubInConstruction ? (
                      <SafeLink
                        key={subItem.href}
                        href={subItem.href}
                        inConstruction={false}
                        className={cn(
                          "flex items-center justify-between rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200 ease-in-out",
                          isSubActive ? "text-primary font-bold bg-primary/5" : "text-gray-700 hover:bg-gray-100",
                        )}
                      >
                        <span>{subItem.title}</span>
                        {isSubActive && <div className="h-1.5 w-1.5 rounded-full bg-primary" />}
                      </SafeLink>
                    ) : (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className={cn(
                          "flex items-center justify-between rounded-lg px-3 py-1.5 text-xs font-medium transition-all duration-200 ease-in-out",
                          isSubActive ? "text-primary font-bold bg-primary/5" : "text-gray-700 hover:bg-gray-100",
                        )}
                      >
                        <span>{subItem.title}</span>
                        {isSubActive && <div className="h-1.5 w-1.5 rounded-full bg-primary" />}
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </nav>

      {/* Botão de logout */}
      <div className="border-t border-gray-200 p-4">
        <button
          onClick={handleLogout}
          className="flex items-center justify-center gap-2 rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-black transition-colors hover:bg-gray-200 w-full"
        >
          <LogOut className="h-4 w-4 text-black" />
          <span>Sair da conta</span>
        </button>
      </div>
    </aside>
  )
}

// Exportação adicional para compatibilidade
export const Sidebar = DashboardSidebar
