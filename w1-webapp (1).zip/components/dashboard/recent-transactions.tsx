import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { MoreHorizontal, ArrowUpRight } from "lucide-react"

interface Transaction {
  id: string
  name: string
  email: string
  amount: string
  status: "completed" | "pending" | "failed"
  date: string
}

const transactions: Transaction[] = [
  {
    id: "1",
    name: "Empresa ABC",
    email: "financeiro@abc.com",
    amount: "R$ 2.500,00",
    status: "completed",
    date: "Hoje, 14:30",
  },
  {
    id: "2",
    name: "Fornecedor XYZ",
    email: "contato@xyz.com",
    amount: "R$ 1.890,00",
    status: "pending",
    date: "Hoje, 10:15",
  },
  {
    id: "3",
    name: "Distribuidora 123",
    email: "pagamentos@123.com",
    amount: "R$ 3.200,00",
    status: "completed",
    date: "Ontem, 16:45",
  },
  {
    id: "4",
    name: "Serviços Tech",
    email: "financeiro@tech.com",
    amount: "R$ 750,00",
    status: "failed",
    date: "Ontem, 09:20",
  },
]

export function RecentTransactions() {
  return (
    <Card className="border-gray-200 bg-white text-gray-900 backdrop-blur-sm hover-lift transition-all duration-300">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-lg font-medium">Transações Recentes</CardTitle>
          <CardDescription className="text-gray-700">Últimas 4 transações do seu negócio</CardDescription>
        </div>
        <button className="rounded-full p-2 hover:bg-gray-800/50 transition-colors">
          <MoreHorizontal className="h-5 w-5 text-gray-400" />
        </button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between rounded-lg p-3 hover:bg-gray-50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <Avatar className="h-10 w-10 border border-gray-300">
                  <AvatarImage src={`/avatar-placeholder.png`} alt={transaction.name} />
                  <AvatarFallback className="bg-gradient-to-br from-teal-400 to-cyan-500 text-gray-900 font-medium">
                    {transaction.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium leading-none text-gray-900">{transaction.name}</p>
                  <p className="text-xs text-gray-700">{transaction.email}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{transaction.amount}</p>
                <div className="flex items-center justify-end gap-1 mt-1">
                  <Badge
                    className={cn(
                      "h-5 px-1.5 text-[10px] font-medium",
                      transaction.status === "completed"
                        ? "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                        : transaction.status === "pending"
                          ? "bg-amber-500/20 text-amber-400 hover:bg-amber-500/30"
                          : "bg-rose-500/20 text-rose-400 hover:bg-rose-500/30",
                    )}
                  >
                    {transaction.status === "completed"
                      ? "Concluído"
                      : transaction.status === "pending"
                        ? "Pendente"
                        : "Falhou"}
                  </Badge>
                  <span className="text-xs text-gray-700">{transaction.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t border-gray-800/50">
          <button className="w-full flex items-center justify-center gap-1 text-sm text-teal-400 hover:text-teal-300 transition-colors">
            <span>Ver todas as transações</span>
            <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
      </CardContent>
    </Card>
  )
}
