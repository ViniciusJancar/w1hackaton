"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, ShieldAlert, Shield } from "lucide-react"
import { cn } from "@/lib/utils"

interface MapaRiscosDetalhadoProps {
  className?: string
}

export function MapaRiscosDetalhado({ className }: MapaRiscosDetalhadoProps) {
  const [categoriaSelecionada, setCategoriaSelecionada] = useState("todos")

  return (
    <Card className={cn("border-gray-200 bg-white text-gray-800 transition-all duration-300 shadow-sm", className)}>
      <CardHeader className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-base sm:text-lg font-medium">Mapa de Riscos Fiscais Detalhado</CardTitle>
            <CardDescription className="text-sm text-gray-600">
              Análise completa de riscos e oportunidades
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
        <Tabs defaultValue="mapa" className="w-full">
          <TabsList className="grid grid-cols-3 bg-gray-100">
            <TabsTrigger
              value="mapa"
              className="text-xs sm:text-sm data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Mapa de Riscos
            </TabsTrigger>
            <TabsTrigger
              value="mitigacao"
              className="text-xs sm:text-sm data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Estratégias
            </TabsTrigger>
            <TabsTrigger
              value="alertas"
              className="text-xs sm:text-sm data-[state=active]:bg-teal-600 data-[state=active]:text-white"
            >
              Alertas
            </TabsTrigger>
          </TabsList>

          <div className="flex flex-wrap gap-2 mt-4 mb-2">
            <Badge
              variant="outline"
              className={cn(
                "text-xs cursor-pointer hover:bg-gray-100",
                categoriaSelecionada === "todos"
                  ? "bg-teal-100 text-teal-800 border-teal-200"
                  : "bg-white text-gray-700 border-gray-300",
              )}
              onClick={() => setCategoriaSelecionada("todos")}
            >
              Todos
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-xs cursor-pointer hover:bg-gray-100",
                categoriaSelecionada === "tributario"
                  ? "bg-teal-100 text-teal-800 border-teal-200"
                  : "bg-white text-gray-700 border-gray-300",
              )}
              onClick={() => setCategoriaSelecionada("tributario")}
            >
              Tributário
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-xs cursor-pointer hover:bg-gray-100",
                categoriaSelecionada === "sucessorio"
                  ? "bg-teal-100 text-teal-800 border-teal-200"
                  : "bg-white text-gray-700 border-gray-300",
              )}
              onClick={() => setCategoriaSelecionada("sucessorio")}
            >
              Sucessório
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-xs cursor-pointer hover:bg-gray-100",
                categoriaSelecionada === "societario"
                  ? "bg-teal-100 text-teal-800 border-teal-200"
                  : "bg-white text-gray-700 border-gray-300",
              )}
              onClick={() => setCategoriaSelecionada("societario")}
            >
              Societário
            </Badge>
            <Badge
              variant="outline"
              className={cn(
                "text-xs cursor-pointer hover:bg-gray-100",
                categoriaSelecionada === "compliance"
                  ? "bg-teal-100 text-teal-800 border-teal-200"
                  : "bg-white text-gray-700 border-gray-300",
              )}
              onClick={() => setCategoriaSelecionada("compliance")}
            >
              Compliance
            </Badge>
          </div>

          <TabsContent value="mapa" className="mt-2">
            <MapaRiscos categoria={categoriaSelecionada} />
          </TabsContent>

          <TabsContent value="mitigacao" className="mt-2">
            <EstrategiasMitigacao categoria={categoriaSelecionada} />
          </TabsContent>

          <TabsContent value="alertas" className="mt-2">
            <AlertasFiscais categoria={categoriaSelecionada} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function MapaRiscos({ categoria }: { categoria: string }) {
  // Dados de riscos fiscais
  const riscos = [
    {
      id: 1,
      nome: "Distribuição desproporcional de lucros",
      categoria: "tributario",
      impacto: "alto",
      probabilidade: "media",
      descricao:
        "Risco de questionamento fiscal sobre distribuição desproporcional de lucros sem o devido suporte documental.",
    },
    {
      id: 2,
      nome: "Integralização de bens com valores divergentes",
      categoria: "tributario",
      impacto: "alto",
      probabilidade: "alta",
      descricao:
        "Risco de questionamento sobre valores de integralização de bens em sociedades, gerando possíveis ganhos de capital.",
    },
    {
      id: 3,
      nome: "Ausência de acordo de sócios",
      categoria: "societario",
      impacto: "medio",
      probabilidade: "alta",
      descricao: "Falta de regras claras para entrada/saída de sócios, resolução de conflitos e sucessão empresarial.",
    },
    {
      id: 4,
      nome: "Testamento desatualizado",
      categoria: "sucessorio",
      impacto: "alto",
      probabilidade: "media",
      descricao: "Risco de disputas familiares e judicialização da sucessão por falta de planejamento adequado.",
    },
    {
      id: 5,
      nome: "Confusão patrimonial",
      categoria: "compliance",
      impacto: "alto",
      probabilidade: "alta",
      descricao:
        "Mistura entre patrimônio pessoal e empresarial, podendo gerar desconsideração da personalidade jurídica.",
    },
    {
      id: 6,
      nome: "Doações sem reserva de usufruto",
      categoria: "sucessorio",
      impacto: "medio",
      probabilidade: "media",
      descricao: "Transferência de patrimônio sem proteção do doador, gerando possível dependência financeira.",
    },
    {
      id: 7,
      nome: "Estrutura societária inadequada",
      categoria: "societario",
      impacto: "medio",
      probabilidade: "alta",
      descricao: "Estrutura que não reflete as necessidades do negócio ou família, gerando ineficiências fiscais.",
    },
    {
      id: 8,
      nome: "Declarações acessórias incompletas",
      categoria: "compliance",
      impacto: "medio",
      probabilidade: "media",
      descricao: "Omissão ou erro em declarações como DBE, DIRPF, DIRF, podendo gerar multas e fiscalizações.",
    },
  ]

  // Filtrar riscos pela categoria selecionada
  const riscosFiltrados = categoria === "todos" ? riscos : riscos.filter((risco) => risco.categoria === categoria)

  // Mapear cores de impacto
  const coresImpacto = {
    baixo: "bg-emerald-500",
    medio: "bg-amber-500",
    alto: "bg-rose-500",
  }

  // Mapear cores de probabilidade
  const coresProbabilidade = {
    baixa: "bg-emerald-500",
    media: "bg-amber-500",
    alta: "bg-rose-500",
  }

  return (
    <div className="space-y-3 sm:space-y-4">
      <div className="grid grid-cols-1 gap-3">
        {riscosFiltrados.map((risco) => (
          <div key={risco.id} className="bg-gray-50 rounded-lg p-3 sm:p-4 border border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0 items-center justify-center rounded-full bg-gray-100 text-gray-600">
                  <AlertTriangle className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-medium text-gray-800">{risco.nome}</p>
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2 sm:line-clamp-none">{risco.descricao}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 ml-0 md:ml-4 mt-2 md:mt-0">
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-600 mb-1">Impacto</span>
                  <div
                    className={`w-12 sm:w-16 h-2 rounded-full ${coresImpacto[risco.impacto as keyof typeof coresImpacto]}`}
                  ></div>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-xs text-gray-600 mb-1">Probabilidade</span>
                  <div
                    className={`w-12 sm:w-16 h-2 rounded-full ${coresProbabilidade[risco.probabilidade as keyof typeof coresProbabilidade]}`}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {riscosFiltrados.length === 0 && (
        <div className="bg-gray-50 rounded-lg p-4 sm:p-6 text-center border border-gray-200">
          <p className="text-sm text-gray-600">Nenhum risco encontrado para esta categoria.</p>
        </div>
      )}
    </div>
  )
}

function EstrategiasMitigacao({ categoria }: { categoria: string }) {
  // Dados de estratégias de mitigação
  const estrategias = [
    {
      id: 1,
      nome: "Acordo de sócios",
      categoria: "societario",
      descricao:
        "Elaboração de acordo de sócios com regras claras para entrada/saída, resolução de conflitos e sucessão.",
      impacto: "Redução de riscos societários e sucessórios, prevenção de conflitos futuros.",
    },
    {
      id: 2,
      nome: "Holding familiar",
      categoria: "sucessorio",
      descricao: "Estruturação de holding para centralizar patrimônio e facilitar sucessão com economia tributária.",
      impacto: "Proteção patrimonial, redução de custos sucessórios, blindagem contra riscos.",
    },
    {
      id: 3,
      nome: "Planejamento tributário",
      categoria: "tributario",
      descricao: "Análise e implementação de estrutura tributária otimizada para operações empresariais e familiares.",
      impacto: "Economia fiscal lícita, prevenção de autuações, segurança jurídica.",
    },
    {
      id: 4,
      nome: "Testamento e doações planejadas",
      categoria: "sucessorio",
      descricao: "Elaboração de testamento e planejamento de doações com reserva de usufruto e cláusulas protetivas.",
      impacto: "Garantia da vontade do titular, proteção dos herdeiros, redução de custos e conflitos.",
    },
    {
      id: 5,
      nome: "Governança corporativa",
      categoria: "compliance",
      descricao: "Implementação de práticas de governança, com separação clara entre patrimônio pessoal e empresarial.",
      impacto:
        "Profissionalização da gestão, transparência, proteção contra desconsideração da personalidade jurídica.",
    },
    {
      id: 6,
      nome: "Revisão de estruturas societárias",
      categoria: "societario",
      descricao: "Análise e reestruturação de grupos empresariais para otimização fiscal e operacional.",
      impacto: "Simplificação administrativa, redução de custos operacionais e tributários.",
    },
  ]

  // Filtrar estratégias pela categoria selecionada
  const estrategiasFiltradas =
    categoria === "todos" ? estrategias : estrategias.filter((estrategia) => estrategia.categoria === categoria)

  return (
    <div className="space-y-3 sm:space-y-4">
      <div className="grid grid-cols-1 gap-3">
        {estrategiasFiltradas.map((estrategia) => (
          <div key={estrategia.id} className="bg-gray-50 rounded-lg p-3 sm:p-4 border border-gray-200">
            <div className="flex flex-col gap-2">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0 items-center justify-center rounded-full bg-gray-100 text-teal-600">
                  <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-medium text-gray-800">{estrategia.nome}</p>
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2 sm:line-clamp-none">{estrategia.descricao}</p>
                </div>
              </div>
              <div className="mt-2 ml-11 sm:ml-13 pl-0 sm:pl-10">
                <p className="text-xs font-medium text-teal-600">Impacto esperado:</p>
                <p className="text-xs text-gray-600">{estrategia.impacto}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {estrategiasFiltradas.length === 0 && (
        <div className="bg-gray-50 rounded-lg p-4 sm:p-6 text-center border border-gray-200">
          <p className="text-sm text-gray-600">Nenhuma estratégia encontrada para esta categoria.</p>
        </div>
      )}
    </div>
  )
}

function AlertasFiscais({ categoria }: { categoria: string }) {
  // Dados de alertas fiscais
  const alertas = [
    {
      id: 1,
      nome: "Alteração na tributação de dividendos",
      categoria: "tributario",
      descricao: "Projeto de lei em tramitação que pode instituir tributação sobre dividendos distribuídos.",
      impacto: "Aumento da carga tributária para sócios e acionistas de empresas.",
      status: "pendente",
    },
    {
      id: 2,
      nome: "Mudanças no ITCMD",
      categoria: "sucessorio",
      descricao: "Alterações nas alíquotas e base de cálculo do Imposto sobre Transmissão Causa Mortis e Doação.",
      impacto: "Possível aumento do custo tributário em doações e heranças.",
      status: "ativo",
    },
    {
      id: 3,
      nome: "Fiscalização de distribuição desproporcional",
      categoria: "tributario",
      descricao: "Aumento de fiscalizações sobre distribuição desproporcional de lucros sem justificativa.",
      impacto: "Risco de autuações e requalificação como pagamento de serviços ou doação.",
      status: "ativo",
    },
    {
      id: 4,
      nome: "Novas obrigações acessórias",
      categoria: "compliance",
      descricao: "Implementação de novas declarações e obrigações acessórias para pessoas físicas e jurídicas.",
      impacto: "Necessidade de adaptação e risco de penalidades por descumprimento.",
      status: "pendente",
    },
    {
      id: 5,
      nome: "Alterações no regime de holdings",
      categoria: "societario",
      descricao: "Possíveis mudanças na legislação que afetam o tratamento tributário de holdings patrimoniais.",
      impacto: "Potencial redução de benefícios fiscais para estruturas patrimoniais.",
      status: "pendente",
    },
  ]

  // Filtrar alertas pela categoria selecionada
  const alertasFiltrados = categoria === "todos" ? alertas : alertas.filter((alerta) => alerta.categoria === categoria)

  return (
    <div className="space-y-3 sm:space-y-4">
      <div className="grid grid-cols-1 gap-3">
        {alertasFiltrados.map((alerta) => (
          <div key={alerta.id} className="bg-gray-50 rounded-lg p-3 sm:p-4 border border-gray-200">
            <div className="flex flex-col gap-2">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 sm:h-10 sm:w-10 flex-shrink-0 items-center justify-center rounded-full bg-gray-100 text-amber-600">
                  <ShieldAlert className="h-4 w-4 sm:h-5 sm:w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <p className="text-xs sm:text-sm font-medium text-gray-800">{alerta.nome}</p>
                    <Badge
                      variant="outline"
                      className={
                        alerta.status === "ativo"
                          ? "text-xs bg-rose-100 text-rose-700 border-rose-200 w-fit"
                          : "text-xs bg-amber-100 text-amber-700 border-amber-200 w-fit"
                      }
                    >
                      {alerta.status === "ativo" ? "Ativo" : "Pendente"}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mt-1 line-clamp-2 sm:line-clamp-none">{alerta.descricao}</p>
                </div>
              </div>
              <div className="mt-2 ml-11 sm:ml-13 pl-0 sm:pl-10">
                <p className="text-xs font-medium text-amber-600">Possível impacto:</p>
                <p className="text-xs text-gray-600">{alerta.impacto}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {alertasFiltrados.length === 0 && (
        <div className="bg-gray-50 rounded-lg p-4 sm:p-6 text-center border border-gray-200">
          <p className="text-sm text-gray-600">Nenhum alerta encontrado para esta categoria.</p>
        </div>
      )}
    </div>
  )
}
