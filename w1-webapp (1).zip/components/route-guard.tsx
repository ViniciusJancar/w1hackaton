"use client"

import type React from "react"

import { useAuth } from "@/lib/auth-context"
import { useRouter, usePathname } from "next/navigation"
import { useEffect } from "react"

export function RouteGuard({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (!isLoading) {
      // Check if current route requires authentication
      const protectedRoutes = ["/dashboard"]
      const isProtectedRoute = protectedRoutes.some((route) => pathname.startsWith(route))

      if (isProtectedRoute && !user) {
        router.push(`/login?callbackUrl=${encodeURIComponent(pathname)}`)
      }

      // Redirect authenticated users away from auth pages
      const authRoutes = ["/login", "/cadastro"]
      const isAuthRoute = authRoutes.includes(pathname)

      if (isAuthRoute && user) {
        router.push("/dashboard")
      }
    }
  }, [user, isLoading, pathname, router])

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
      </div>
    )
  }

  return <>{children}</>
}
