"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChartIcon as ChartBar, Download, X } from "lucide-react"
import type { CalculationResult } from "./calculadora-fiscal"

type ResultadoCalculadoraProps = {
  result: CalculationResult
  onClose: () => void
  onNewCalculation: () => void
}

export function ResultadoCalculadora({ result, onClose, onNewCalculation }: ResultadoCalculadoraProps) {
  const formatCurrency = (value: number) => {
    return value.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
    })
  }

  const formatPercentage = (value: number) => {
    return value.toFixed(2).replace(".", ",") + "%"
  }

  const getTipoPatrimonioLabel = (tipo: string) => {
    switch (tipo) {
      case "imoveis":
        return "Imóveis"
      case "investimentos":
        return "Investimentos financeiros"
      case "empresas":
        return "Participações em empresas"
      case "misto":
        return "Patrimônio misto"
      default:
        return tipo
    }
  }

  return (
    <Card className="w-full bg-white border-gray-200 text-gray-900">
      <CardHeader className="bg-gray-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChartBar className="h-5 w-5 text-teal-500" />
            <CardTitle className="text-lg text-gray-900">Resultado da Simulação</CardTitle>
          </div>
          <button onClick={onClose} className="text-gray-700 hover:text-gray-900">
            <X className="h-5 w-5" />
          </button>
        </div>
        <CardDescription className="text-gray-700">
          Estimativa de economia com estruturação patrimonial via holding
        </CardDescription>
      </CardHeader>

      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="text-center">
            <p className="text-gray-700 mb-1">Economia total estimada</p>
            <p className="text-3xl font-bold text-teal-500">{formatCurrency(result.economiaTotal)}</p>
            <p className="text-sm text-teal-400">
              Aproximadamente {formatPercentage(result.economiaPorcentagem)} do patrimônio
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 text-sm mb-1">Economia em ITCMD</p>
              <p className="text-xl font-semibold text-gray-900">{formatCurrency(result.economiaITCMD)}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 text-sm mb-1">Economia em IR</p>
              <p className="text-xl font-semibold text-gray-900">{formatCurrency(result.economiaIR)}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 text-sm mb-1">Outras economias</p>
              <p className="text-xl font-semibold text-gray-900">{formatCurrency(result.economiaOutros)}</p>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-gray-700 text-sm mb-2">Detalhes da simulação</p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Valor do patrimônio:</span>
                <span className="text-gray-900">{formatCurrency(result.valorPatrimonio)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tipo de patrimônio:</span>
                <span className="text-gray-900">{getTipoPatrimonioLabel(result.tipoPatrimonio)}</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-teal-500">
            <p className="text-sm text-gray-900">
              <span className="font-semibold">Importante:</span> Esta é apenas uma estimativa simplificada. A economia
              real pode variar conforme a situação específica, legislação vigente e estrutura patrimonial detalhada.
            </p>
          </div>
        </div>
      </CardContent>

      <CardFooter className="flex justify-between border-t border-gray-200 bg-white pt-4">
        <Button
          variant="outline"
          onClick={onNewCalculation}
          className="border-gray-700 text-gray-300 hover:bg-gray-100 hover:text-gray-900"
        >
          Nova simulação
        </Button>
        <Button className="bg-teal-600 text-white hover:bg-teal-700">
          <span className="flex items-center gap-2">
            <Download className="h-4 w-4" /> Baixar relatório
          </span>
        </Button>
      </CardFooter>
    </Card>
  )
}
