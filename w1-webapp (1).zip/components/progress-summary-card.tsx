import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ArrowRight, Clock } from "lucide-react"
import Link from "next/link"

interface ProgressSummaryCardProps {
  currentStep: number
  totalSteps: number
  currentStepName: string
  nextStepName?: string
  estimatedTime?: string
  actionLink?: string
  actionText?: string
}

export function ProgressSummaryCard({
  currentStep,
  totalSteps,
  currentStepName,
  nextStepName,
  estimatedTime = "2-3 dias úteis",
  actionLink = "#",
  actionText = "Continuar Processo",
}: ProgressSummaryCardProps) {
  const progress = Math.round((currentStep / totalSteps) * 100)

  return (
    <Card className="mb-8 overflow-hidden border-0 bg-white shadow-lg card-hover">
      <div className="border-l-4 border-blue-500 p-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 high-contrast-text">Seu Progresso na Jornada</h3>
            <p className="mt-2 text-base text-gray-700">
              Estamos avançando bem no seu processo de estruturação patrimonial
            </p>

            <div className="mt-6">
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-gray-800">Progresso Total</span>
                <span className="font-bold text-teal-400">{progress}%</span>
              </div>
              <div className="h-4 w-full overflow-hidden rounded-full bg-gray-200">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-teal-500 to-blue-500 transition-all duration-1000"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4 border-l border-gray-200 pl-6">
            <div>
              <p className="text-sm text-gray-600">Etapa Atual</p>
              <p className="text-lg font-medium text-blue-400">
                {currentStep}. {currentStepName}
              </p>
            </div>

            {nextStepName && (
              <div>
                <p className="text-sm text-gray-600">Próxima Etapa</p>
                <p className="text-base text-gray-700">
                  {currentStep + 1}. {nextStepName}
                </p>
              </div>
            )}

            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-gray-600" />
              <p className="text-sm text-gray-600">
                Tempo estimado: <span className="text-gray-700">{estimatedTime}</span>
              </p>
            </div>

            <Link href={actionLink}>
              <Button className="w-full bg-blue-600 text-gray-100 hover:bg-blue-700 button-large btn-hover">
                {actionText}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </Card>
  )
}
