"use client"

import { useState } from "react"
import { HelpCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ContextualHelpProps {
  title: string
  content: string
  size?: "sm" | "md" | "lg"
  position?: "top" | "right" | "bottom" | "left"
}

export function ContextualHelp({ title, content, size = "md", position = "top" }: ContextualHelpProps) {
  const [isOpen, setIsOpen] = useState(false)

  const sizeClasses = {
    sm: "w-56",
    md: "w-72",
    lg: "w-96",
  }

  const positionClasses = {
    top: "bottom-full left-1/2 -translate-x-1/2 mb-2",
    right: "left-full top-1/2 -translate-y-1/2 ml-2",
    bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
    left: "right-full top-1/2 -translate-y-1/2 mr-2",
  }

  return (
    <div className="relative inline-block help-tooltip">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-full bg-gray-700 p-1.5 text-gray-300 hover:bg-gray-600 hover:text-white focus-visible"
        aria-label={isOpen ? "Fechar ajuda" : "Mostrar ajuda sobre " + title}
      >
        <HelpCircle className="h-5 w-5" />
      </button>

      {isOpen && (
        <div
          className={`absolute z-10 ${positionClasses[position]} ${sizeClasses[size]} rounded-lg border border-gray-700 bg-gray-800 p-4 shadow-lg`}
        >
          <div className="flex items-start justify-between">
            <h4 className="text-base font-medium text-gray-100">{title}</h4>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-gray-400 hover:text-white"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-gray-300">{content}</p>
          <Button
            variant="ghost"
            size="sm"
            className="mt-3 text-teal-400 hover:text-teal-300"
            onClick={() => setIsOpen(false)}
          >
            Entendi
          </Button>
        </div>
      )}
    </div>
  )
}
