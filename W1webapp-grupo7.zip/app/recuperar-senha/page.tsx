"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, CheckCircle, Loader2 } from "lucide-react"
import { z } from "zod"

const emailSchema = z.object({
  email: z.string().email({ message: "Email inválido" }),
})

export default function RecuperarSenhaPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [email, setEmail] = useState("")
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // Validar email
      emailSchema.parse({ email })

      // Resetar erro
      setError(null)

      // Simular envio de email
      setIsLoading(true)

      // Simulação de uma chamada de API
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Mostrar mensagem de sucesso
      setIsSuccess(true)
    } catch (error) {
      if (error instanceof z.ZodError) {
        setError(error.errors[0].message)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#0A1017] text-white">
      {/* Header */}
      <header className="w-full border-b border-gray-800 bg-[#0A1017] py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 72 36"
              height="36"
              width="72"
              className="mr-2"
            >
              <g clipPath="url(#clip0_2635_2144)">
                <path
                  fill="#FFFFFF"
                  d="M45.2869 8.52863H56.5388L34.9322 35.9999L26.6178 35.9932C24.1433 35.9932 22.1383 33.965 22.1383 31.4672V22.7596L11.7349 35.9999H4.48394C2.00714 35.9999 0 33.9739 0 31.4739V8.52863H8.99446V25.2596L22.1406 8.52863H31.1062V26.5767L45.2869 8.52863ZM72 4.52366C72 2.02363 69.9929 -0.00233459 67.5161 -0.00233459H51.9862L47.9963 5.07599H59.2327V35.9977H71.9978V4.5259L72 4.52366Z"
                ></path>
              </g>
              <defs>
                <clipPath id="clip0_2635_2144">
                  <rect fill="white" height="36" width="72"></rect>
                </clipPath>
              </defs>
            </svg>
          </Link>
          <Link href="/login" className="flex items-center text-sm text-gray-400 hover:text-teal-400 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar para o login
          </Link>
        </div>
      </header>

      <main className="flex flex-1 items-center justify-center px-4 py-12 relative overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <Image src="/abstract-pattern-dark.png" alt="Background pattern" fill className="object-cover" />
        </div>

        <div className="w-full max-w-md z-10">
          <div className="rounded-xl border border-gray-800 bg-gray-900/50 p-8 backdrop-blur-sm">
            {isSuccess ? (
              <div className="text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-teal-900/30 mb-4">
                  <CheckCircle className="h-6 w-6 text-teal-400" />
                </div>
                <h1 className="text-2xl font-bold tracking-tight text-white mb-2">Email enviado</h1>
                <p className="text-gray-400 mb-6">
                  Enviamos um link para recuperação de senha para <span className="text-teal-400">{email}</span>.
                  Verifique sua caixa de entrada e siga as instruções.
                </p>
                <Button asChild className="bg-teal-400 hover:bg-teal-500 text-black font-medium">
                  <Link href="/login">Voltar para o login</Link>
                </Button>
              </div>
            ) : (
              <>
                <div className="mb-8 text-center">
                  <h1 className="text-2xl font-bold tracking-tight text-white">Recuperar senha</h1>
                  <p className="mt-2 text-sm text-gray-400">
                    Informe seu email para receber um link de recuperação de senha
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value)
                        setError(null)
                      }}
                      className={`bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500 ${
                        error ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-teal-500"
                      }`}
                      disabled={isLoading}
                      required
                    />
                    {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-teal-400 hover:bg-teal-500 text-black font-medium"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      "Enviar link de recuperação"
                    )}
                  </Button>
                </form>
              </>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
