/**
 * API para verificar o status da conexão com o banco de dados
 */

import { NextResponse } from "next/server"
import { checkDatabaseConnection } from "@/lib/db"

export async function GET() {
  try {
    const status = await checkDatabaseConnection()

    return NextResponse.json({
      status: status.connected ? "online" : "offline",
      message: status.message,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error checking database status:", error)

    return NextResponse.json(
      {
        status: "error",
        message: "Erro ao verificar status do banco de dados",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
