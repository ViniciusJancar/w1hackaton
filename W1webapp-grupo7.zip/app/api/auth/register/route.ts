import { NextResponse } from "next/server"

// Em um ambiente real, você usaria um banco de dados
// Este é apenas um exemplo para demonstração
const users = [
  {
    id: "1",
    name: "Administrador",
    email: "admin@w1.com.br",
    password: "password", // Em produção, use hash de senha
    role: "admin",
  },
  {
    id: "2",
    name: "Cliente Exemplo",
    email: "cliente@exemplo.com",
    password: "password",
    role: "client",
  },
]

export async function POST(request: Request) {
  try {
    const { nome, email, password } = await request.json()

    // Verificar se o email já está em uso
    const existingUser = users.find((user) => user.email === email)
    if (existingUser) {
      return NextResponse.json({ error: "Este email já está em uso" }, { status: 400 })
    }

    // Em um ambiente real, você salvaria no banco de dados
    // e faria hash da senha antes de armazenar
    const newUser = {
      id: String(users.length + 1),
      name: nome,
      email,
      password, // Em produção, use bcrypt para hash
      role: "client", // Papel padrão para novos usuários
    }

    // Adicionar à lista de usuários (simulação)
    users.push(newUser)

    return NextResponse.json(
      {
        success: true,
        user: {
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Erro ao registrar usuário:", error)
    return NextResponse.json({ error: "Erro ao processar o registro" }, { status: 500 })
  }
}
