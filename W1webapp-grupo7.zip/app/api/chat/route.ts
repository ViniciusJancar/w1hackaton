import { openai } from "@ai-sdk/openai"
import { generateText } from "ai"

// Sistema de contexto para o assistente
const systemPrompt = `
Você é um assistente virtual especializado em holding patrimonial da empresa W1, focado em atender clientes de faixa etária mais avançada.

Seu objetivo é fornecer respostas claras, diretas e úteis sobre:
- Processo de constituição de holding patrimonial
- Etapas do processo (análise patrimonial, documentação, planejamento tributário, etc.)
- Status atual do processo do cliente
- Documentos necessários
- Vantagens fiscais e patrimoniais
- Proteção de patrimônio
- Planejamento sucessório

Diretrizes importantes:
1. Use linguagem simples e evite termos técnicos desnecessários
2. Seja conciso e direto nas respostas
3. Quando não souber uma informação específica do cliente, explique que precisaria consultar o sistema
4. Ofereça sempre ajuda adicional ao final da resposta
5. Seja respeitoso e paciente, considerando que o público pode ter dificuldades com tecnologia

Informações da W1 Holding Patrimonial:
- Empresa especializada em constituição de holdings patrimoniais
- Processo completo tem 7 etapas: Análise Inicial, Entrevista, Documentação, Planejamento Tributário, Elaboração Contratual, Registro e Implementação
- Contato: (11) 3456-7890 ou contato@w1holding.com.br
- Horário de atendimento: Segunda a Sexta, das 9h às 18h

Exemplos de vantagens da holding patrimonial:
1. Redução da carga tributária na sucessão patrimonial
2. Proteção patrimonial contra riscos de negócios
3. Planejamento sucessório eficiente
4. Gestão centralizada de bens e investimentos
5. Otimização fiscal legal

Exemplos de documentos necessários:
1. Documentos pessoais dos sócios (RG, CPF)
2. Certidões de casamento ou união estável
3. Matrículas atualizadas dos imóveis
4. Documentos dos veículos
5. Extratos de investimentos
6. Contratos sociais de outras empresas
`

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()

    // Verificar se há mensagens
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return new Response(JSON.stringify({ error: "Formato de mensagem inválido" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    console.log("Mensagens recebidas:", JSON.stringify(messages, null, 2))

    // Preparar o histórico de mensagens para a API
    const formattedMessages = messages.map((msg) => {
      // Verificar o formato da mensagem e adaptar conforme necessário
      if (msg.sender !== undefined) {
        return {
          role: msg.sender === "user" ? "user" : "assistant",
          content: msg.text,
        }
      } else if (msg.role !== undefined) {
        return {
          role: msg.role,
          content: msg.content,
        }
      } else {
        // Formato desconhecido, tentar inferir
        const isUser = msg.content?.includes("user") || msg.text?.includes("user") || false
        return {
          role: isUser ? "user" : "assistant",
          content: msg.content || msg.text || "",
        }
      }
    })

    console.log("Mensagens formatadas:", JSON.stringify(formattedMessages, null, 2))

    // Adicionar o prompt do sistema
    const fullMessages = [{ role: "system", content: systemPrompt }, ...formattedMessages]

    try {
      // Gerar resposta usando a OpenAI
      const { text } = await generateText({
        model: openai("gpt-4o"),
        messages: fullMessages,
      })

      console.log("Resposta da OpenAI:", text)

      return new Response(JSON.stringify({ response: text }), {
        headers: { "Content-Type": "application/json" },
      })
    } catch (aiError) {
      console.error("Erro específico da OpenAI:", aiError)

      // Retornar uma resposta de fallback em caso de erro da OpenAI
      return new Response(
        JSON.stringify({
          response:
            "Desculpe, estou com dificuldades técnicas no momento. Por favor, tente novamente em alguns instantes ou entre em contato pelo telefone (11) 3456-7890.",
        }),
        {
          headers: { "Content-Type": "application/json" },
        },
      )
    }
  } catch (error) {
    console.error("Erro ao processar a solicitação:", error)
    return new Response(JSON.stringify({ error: "Erro ao processar a solicitação", details: String(error) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
