import { ArrowLeft, Calendar, CheckCircle, Clock, Download, FileText, MessageSquare, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function EtapaDetalhes({ params }: { params: { id: string } }) {
  // Dados de exemplo para a etapa
  const etapaId = Number.parseInt(params.id)

  // Dados específicos para cada etapa
  const etapas = [
    {
      id: 1,
      titulo: "Análise Patrimonial Inicial",
      descricao:
        "Nesta etapa, realizamos um levantamento completo dos seus ativos, passivos e estrutura patrimonial atual para estabelecer a base do planejamento.",
      status: "completed",
      dataInicio: "15/04/2023",
      previsaoConclusao: "30/04/2023",
      responsavel: "Dra. Ana Silva",
      cargo: "Especialista em Planejamento Patrimonial",
      progresso: 100,
      documentos: [
        {
          id: 1,
          nome: "Inventário Patrimonial Completo",
          tipo: "PDF",
          tamanho: "3.2 MB",
          data: "28/04/2023",
          status: "Aprovado",
          statusColor: "green",
        },
        {
          id: 2,
          nome: "Relatório de Avaliação de Ativos",
          tipo: "PDF",
          tamanho: "2.5 MB",
          data: "25/04/2023",
          status: "Aprovado",
          statusColor: "green",
        },
        {
          id: 3,
          nome: "Diagnóstico de Riscos Patrimoniais",
          tipo: "PDF",
          tamanho: "1.8 MB",
          data: "27/04/2023",
          status: "Aprovado",
          statusColor: "green",
        },
      ],
      tarefas: [
        {
          id: 1,
          titulo: "Revisar e confirmar inventário patrimonial",
          descricao: "Verificar se todos os ativos foram corretamente listados e avaliados.",
          prazo: "Concluído",
          status: "concluido",
          prioridade: "concluida",
        },
        {
          id: 2,
          titulo: "Agendar reunião de feedback",
          descricao: "Discutir os resultados da análise patrimonial inicial.",
          prazo: "Concluído",
          status: "concluido",
          prioridade: "concluida",
        },
      ],
      proximos_passos: [
        "Definição dos objetivos patrimoniais e sucessórios.",
        "Análise das opções de estruturação patrimonial.",
        "Elaboração da proposta de estrutura jurídica ideal.",
      ],
    },
    {
      id: 2,
      titulo: "Escolha da Estrutura Jurídica e Tipo de Holding",
      descricao:
        "Nesta etapa, definimos o modelo jurídico mais adequado para sua holding com base nos seus objetivos patrimoniais e sucessórios.",
      status: "current",
      dataInicio: "01/05/2023",
      previsaoConclusao: "25/05/2023",
      responsavel: "Dr. Carlos Mendes",
      cargo: "Advogado Especialista em Direito Societário",
      progresso: 60,
      documentos: [
        {
          id: 1,
          nome: "Proposta de Estrutura Jurídica",
          tipo: "PDF",
          tamanho: "2.4 MB",
          data: "15/05/2023",
          status: "Aguardando revisão",
          statusColor: "blue",
        },
        {
          id: 2,
          nome: "Comparativo de Tipos de Holding",
          tipo: "PDF",
          tamanho: "1.8 MB",
          data: "10/05/2023",
          status: "Disponível para download",
          statusColor: "teal",
        },
        {
          id: 3,
          nome: "Análise Tributária das Opções",
          tipo: "PDF",
          tamanho: "3.2 MB",
          data: "12/05/2023",
          status: "Disponível para download",
          statusColor: "teal",
        },
      ],
      tarefas: [
        {
          id: 1,
          titulo: "Revisar proposta de estrutura jurídica",
          descricao: "Analisar o documento enviado e aprovar ou solicitar ajustes.",
          prazo: "25/05/2023",
          status: "pendente",
          prioridade: "alta",
        },
        {
          id: 2,
          titulo: "Agendar reunião para esclarecimentos",
          descricao: "Caso tenha dúvidas sobre a proposta, agende uma reunião com nosso especialista.",
          prazo: "20/05/2023",
          status: "opcional",
          prioridade: "média",
        },
      ],
      proximos_passos: [
        "Após sua aprovação da estrutura jurídica, iniciaremos a elaboração do contrato social.",
        "Será necessário definir as cláusulas específicas de proteção patrimonial.",
        "Prepararemos toda a documentação para registro na Junta Comercial.",
      ],
    },
    {
      id: 3,
      titulo: "Elaboração e Registro de Documentos",
      descricao:
        "Nesta etapa, elaboramos todos os documentos societários necessários e realizamos o registro formal da sua holding.",
      status: "pending",
      dataInicio: "Previsto para 26/05/2023",
      previsaoConclusao: "15/06/2023",
      responsavel: "Dra. Patrícia Oliveira",
      cargo: "Advogada Especialista em Direito Empresarial",
      progresso: 0,
      documentos: [
        {
          id: 1,
          nome: "Modelo de Contrato Social",
          tipo: "DOCX",
          tamanho: "1.2 MB",
          data: "Pendente",
          status: "Em elaboração",
          statusColor: "yellow",
        },
        {
          id: 2,
          nome: "Checklist de Documentos para Registro",
          tipo: "PDF",
          tamanho: "0.8 MB",
          data: "10/05/2023",
          status: "Disponível para download",
          statusColor: "teal",
        },
      ],
      tarefas: [
        {
          id: 1,
          titulo: "Aguardar conclusão da etapa anterior",
          descricao: "Esta etapa iniciará automaticamente após a conclusão da etapa 2.",
          prazo: "N/A",
          status: "aguardando",
          prioridade: "baixa",
        },
      ],
      proximos_passos: [
        "Após a elaboração dos documentos, será necessária sua assinatura.",
        "Realizaremos o registro na Junta Comercial e demais órgãos competentes.",
        "Obteremos o CNPJ e demais documentos fiscais da holding.",
      ],
    },
    {
      id: 4,
      titulo: "Integralização de Bens e Ativos",
      descricao:
        "Nesta etapa, realizamos a transferência legal dos bens e ativos selecionados para a estrutura da holding.",
      status: "pending",
      dataInicio: "Previsto para 16/06/2023",
      previsaoConclusao: "15/07/2023",
      responsavel: "Dr. Roberto Campos",
      cargo: "Especialista em Planejamento Tributário",
      progresso: 0,
      documentos: [
        {
          id: 1,
          nome: "Guia de Integralização de Bens",
          tipo: "PDF",
          tamanho: "1.5 MB",
          data: "10/05/2023",
          status: "Disponível para download",
          statusColor: "teal",
        },
      ],
      tarefas: [
        {
          id: 1,
          titulo: "Aguardar conclusão da etapa anterior",
          descricao: "Esta etapa iniciará automaticamente após a conclusão da etapa 3.",
          prazo: "N/A",
          status: "aguardando",
          prioridade: "baixa",
        },
      ],
      proximos_passos: [
        "Preparação das escrituras de transferência de bens imóveis.",
        "Transferência de participações societárias para a holding.",
        "Atualização dos registros de propriedade em cartórios e juntas comerciais.",
      ],
    },
    {
      id: 5,
      titulo: "Implementação de Governança Familiar",
      descricao:
        "Nesta etapa final, estabelecemos as regras de governança familiar e os protocolos de sucessão para garantir a continuidade do patrimônio.",
      status: "pending",
      dataInicio: "Previsto para 16/07/2023",
      previsaoConclusao: "15/08/2023",
      responsavel: "Dra. Luciana Martins",
      cargo: "Especialista em Governança Familiar",
      progresso: 0,
      documentos: [
        {
          id: 1,
          nome: "Modelo de Protocolo Familiar",
          tipo: "PDF",
          tamanho: "2.0 MB",
          data: "10/05/2023",
          status: "Disponível para download",
          statusColor: "teal",
        },
      ],
      tarefas: [
        {
          id: 1,
          titulo: "Aguardar conclusão da etapa anterior",
          descricao: "Esta etapa iniciará automaticamente após a conclusão da etapa 4.",
          prazo: "N/A",
          status: "aguardando",
          prioridade: "baixa",
        },
      ],
      proximos_passos: [
        "Definição das regras de entrada e saída de membros da família na holding.",
        "Estabelecimento de políticas de dividendos e reinvestimentos.",
        "Criação de mecanismos de resolução de conflitos familiares.",
      ],
    },
  ]

  // Encontrar a etapa correspondente ao ID
  const etapa = etapas.find((e) => e.id === etapaId) || etapas[1] // Fallback para etapa 2 se não encontrar

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <Link href="/dashboard/holding" className="inline-flex items-center text-teal-600 hover:text-teal-500">
          <ArrowLeft className="mr-2 h-4 w-4" />
          <span>Voltar para visão geral</span>
        </Link>
      </div>

      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="max-w-4xl">
          <div className="flex flex-col md:flex-row md:items-center">
            <h1 className="text-3xl font-bold text-black">Etapa {etapaId}:</h1>
            <h2 className="md:ml-2 text-3xl font-bold text-teal-600">{etapa.titulo}</h2>
          </div>
          <p className="mt-2 text-base text-black leading-relaxed">{etapa.descricao}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-white border-gray-200 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-900">Status da Etapa</CardTitle>
              <CardDescription className="text-gray-600">Acompanhe o progresso desta etapa</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-lg font-medium text-gray-900">Progresso Atual</span>
                  <span className="text-lg font-medium text-teal-600">{etapa.progresso}%</span>
                </div>
                <div className="h-3 w-full rounded-full bg-gray-200">
                  <div
                    className="h-3 rounded-full bg-gradient-to-r from-teal-500 to-teal-400"
                    style={{ width: `${etapa.progresso}%` }}
                  ></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center rounded-lg bg-gray-100 p-4">
                    <Calendar className="mr-3 h-5 w-5 text-teal-600 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-gray-600">Data de Início</p>
                      <p className="text-lg font-medium text-gray-900 truncate">{etapa.dataInicio}</p>
                    </div>
                  </div>
                  <div className="flex items-center rounded-lg bg-gray-100 p-4">
                    <Clock className="mr-3 h-5 w-5 text-amber-500 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm text-gray-600">Previsão de Conclusão</p>
                      <p className="text-lg font-medium text-gray-900 truncate">{etapa.previsaoConclusao}</p>
                    </div>
                  </div>
                </div>

                <div className="rounded-lg bg-gray-100 p-4">
                  <p className="text-sm text-gray-600 mb-2">Responsável por esta etapa</p>
                  <div className="flex items-center">
                    <div className="mr-3 h-10 w-10 rounded-full bg-gradient-to-br from-teal-500 to-teal-400 flex items-center justify-center text-white font-bold flex-shrink-0">
                      {etapa.responsavel
                        .split(" ")
                        .map((name) => name[0])
                        .join("")}
                    </div>
                    <div className="min-w-0">
                      <p className="text-lg font-medium text-gray-900 truncate">{etapa.responsavel}</p>
                      <p className="text-sm text-gray-600 truncate">{etapa.cargo}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-900">Documentos da Etapa</CardTitle>
              <CardDescription className="text-gray-600">
                Documentos relacionados a esta etapa do processo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {etapa.documentos.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between rounded-lg bg-gray-100 p-4 hover:bg-gray-200 transition-colors overflow-hidden"
                  >
                    <div className="flex items-center min-w-0 flex-1">
                      <div className="mr-4 rounded-md bg-white p-2 flex-shrink-0 border border-gray-200">
                        <FileText className="h-6 w-6 text-teal-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-lg font-medium text-gray-900 truncate">{doc.nome}</h3>
                        <p className="text-sm text-gray-600 truncate">
                          {doc.tipo} • {doc.tamanho} • {doc.data}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 flex-shrink-0 ml-4">
                      <span
                        className={`inline-flex items-center rounded-full bg-${doc.statusColor}-100 px-2.5 py-1 text-xs font-medium text-${doc.statusColor}-700 whitespace-nowrap`}
                      >
                        {doc.status}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-gray-500 hover:text-gray-700 flex-shrink-0"
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <div className="mt-6 flex justify-center">
                  <Button className="bg-teal-600 text-white hover:bg-teal-500">
                    <Upload className="mr-2 h-4 w-4" />
                    Enviar Novo Documento
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card className="bg-white border-gray-200 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">Ações Necessárias</CardTitle>
              <CardDescription className="text-gray-600">Tarefas que requerem sua atenção</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {etapa.tarefas.map((tarefa) => {
                  let bgColor = "bg-gray-100"
                  let borderColor = "border-gray-200"
                  let textColor = "text-gray-900"
                  let buttonBg = "bg-teal-600"
                  let buttonText = "text-white"
                  let buttonHover = "hover:bg-teal-500"

                  if (tarefa.prioridade === "alta") {
                    bgColor = "bg-red-50"
                    borderColor = "border-red-200"
                    textColor = "text-red-700"
                    buttonBg = "bg-red-600"
                    buttonHover = "hover:bg-red-500"
                  } else if (tarefa.prioridade === "média") {
                    bgColor = "bg-amber-50"
                    borderColor = "border-amber-200"
                    textColor = "text-amber-700"
                    buttonBg = "bg-amber-600"
                    buttonText = "text-black"
                    buttonHover = "hover:bg-amber-500"
                  } else if (tarefa.prioridade === "concluida") {
                    bgColor = "bg-green-50"
                    borderColor = "border-green-200"
                    textColor = "text-green-700"
                    buttonBg = "bg-green-600"
                    buttonHover = "hover:bg-green-500"
                  }

                  return (
                    <div key={tarefa.id} className={`rounded-lg p-4 overflow-hidden ${bgColor} border ${borderColor}`}>
                      <h3 className={`text-lg font-medium mb-2 ${textColor}`}>{tarefa.titulo}</h3>
                      <p className="text-sm text-gray-700 mb-3 leading-relaxed">{tarefa.descricao}</p>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <span className="text-xs text-gray-600">Prazo: {tarefa.prazo}</span>
                        {tarefa.status !== "concluido" && tarefa.status !== "aguardando" && (
                          <Button size="sm" className={`w-full sm:w-auto ${buttonBg} ${buttonText} ${buttonHover}`}>
                            {tarefa.status === "pendente" ? "Realizar Agora" : "Agendar"}
                          </Button>
                        )}
                        {tarefa.status === "concluido" && (
                          <span className="text-green-600 font-medium flex items-center">
                            <CheckCircle className="h-4 w-4 mr-1" /> Concluído
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">Próximos Passos</CardTitle>
              <CardDescription className="text-gray-600">O que acontecerá após esta etapa</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {etapa.proximos_passos.map((passo, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="mr-2 h-5 w-5 text-teal-600 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700 leading-relaxed">{passo}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-white border-gray-200 shadow-md overflow-hidden">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">Precisa de Ajuda?</CardTitle>
              <CardDescription className="text-gray-600">Entre em contato com nossa equipe</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button className="w-full bg-teal-600 text-white hover:bg-teal-500">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Agendar Reunião
                </Button>
                <Button variant="outline" className="w-full border-teal-600 text-teal-600 hover:bg-teal-50">
                  Enviar Mensagem
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
