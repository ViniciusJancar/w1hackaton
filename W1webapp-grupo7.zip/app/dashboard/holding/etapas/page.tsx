import { ArrowRight, CheckCircle, Clock } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function EtapasHolding() {
  // Dados de exemplo para as etapas
  const etapas = [
    {
      id: 1,
      titulo: "Análise Patrimonial Inicial",
      descricao:
        "Levantamento completo dos seus ativos, passivos e estrutura patrimonial atual para estabelecer a base do planejamento.",
      status: "completed",
      dataInicio: "15/04/2023",
      dataConclusao: "30/04/2023",
      progresso: 100,
    },
    {
      id: 2,
      titulo: "Escolha da Estrutura Jurídica e Tipo de Holding",
      descricao:
        "Definição do modelo jurídico mais adequado para sua holding com base nos seus objetivos patrimoniais e sucessórios.",
      status: "current",
      dataInicio: "01/05/2023",
      previsaoConclusao: "25/05/2023",
      progresso: 60,
    },
    {
      id: 3,
      titulo: "Elaboração e Registro de Documentos",
      descricao:
        "Elaboração de todos os documentos societários necessários e realização do registro formal da sua holding.",
      status: "pending",
      previsaoInicio: "26/05/2023",
      previsaoConclusao: "15/06/2023",
      progresso: 0,
    },
    {
      id: 4,
      titulo: "Integralização de Bens e Ativos",
      descricao: "Transferência legal dos bens e ativos selecionados para a estrutura da holding.",
      status: "pending",
      previsaoInicio: "16/06/2023",
      previsaoConclusao: "15/07/2023",
      progresso: 0,
    },
    {
      id: 5,
      titulo: "Implementação de Governança Familiar",
      descricao:
        "Estabelecimento das regras de governança familiar e dos protocolos de sucessão para garantir a continuidade do patrimônio.",
      status: "pending",
      previsaoInicio: "16/07/2023",
      previsaoConclusao: "15/08/2023",
      progresso: 0,
    },
  ]

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Etapas da Constituição da Holding</h1>
        <p className="mt-2 text-gray-600">
          Acompanhe o progresso de cada etapa do processo de constituição da sua holding familiar.
        </p>
      </div>

      <div className="space-y-6">
        {etapas.map((etapa) => {
          let statusBadge
          let dateInfo

          if (etapa.status === "completed") {
            statusBadge = (
              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-700">
                <CheckCircle className="mr-1 h-3 w-3" />
                Concluída
              </span>
            )
            dateInfo = (
              <p className="text-sm text-gray-600">
                <span className="font-medium">Concluída em:</span> {etapa.dataConclusao}
              </p>
            )
          } else if (etapa.status === "current") {
            statusBadge = (
              <span className="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-700">
                <Clock className="mr-1 h-3 w-3" />
                Em Andamento
              </span>
            )
            dateInfo = (
              <p className="text-sm text-gray-600">
                <span className="font-medium">Previsão de conclusão:</span> {etapa.previsaoConclusao}
              </p>
            )
          } else {
            statusBadge = (
              <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-600">
                Pendente
              </span>
            )
            dateInfo = (
              <p className="text-sm text-gray-600">
                <span className="font-medium">Previsão de início:</span> {etapa.previsaoInicio}
              </p>
            )
          }

          return (
            <Card
              key={etapa.id}
              className={`overflow-hidden border ${
                etapa.status === "current"
                  ? "border-teal-200 bg-teal-50"
                  : etapa.status === "completed"
                    ? "border-green-200 bg-green-50"
                    : "border-gray-200 bg-white"
              }`}
            >
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-xl text-gray-900">
                        Etapa {etapa.id}: {etapa.titulo}
                      </CardTitle>
                      {statusBadge}
                    </div>
                    <CardDescription className="mt-1 text-gray-600">{etapa.descricao}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="text-gray-600">Progresso</span>
                      <span className="font-medium text-teal-600">{etapa.progresso}%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div
                        className={`h-2 rounded-full ${etapa.status === "completed" ? "bg-green-500" : "bg-teal-500"}`}
                        style={{ width: `${etapa.progresso}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">Início:</span>{" "}
                        {etapa.dataInicio || etapa.previsaoInicio || "A definir"}
                      </p>
                      {dateInfo}
                    </div>

                    <Link
                      href={`/dashboard/holding/etapas/${etapa.id}`}
                      className={`inline-flex items-center rounded-md px-4 py-2 text-sm font-medium ${
                        etapa.status === "pending"
                          ? "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          : "bg-teal-600 text-white hover:bg-teal-500"
                      }`}
                    >
                      {etapa.status === "completed"
                        ? "Ver Detalhes"
                        : etapa.status === "current"
                          ? "Continuar Etapa"
                          : "Visualizar"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
