import { Briefcase, FileText, Users, Building, Scale, FileCheck, Receipt, Home, Shield, HeartPulse } from "lucide-react"
import { TimelineStep } from "@/components/timeline-step"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function HoldingPage() {
  // Dados das etapas do processo de holding
  const etapas = [
    {
      icon: Briefcase,
      title: "Planejamento Inicial e Definição de Objetivos",
      description: "Definimos juntos os objetivos da sua holding patrimonial e elaboramos um plano personalizado.",
      status: "completed" as const,
      step: 1,
      actionLink: "/dashboard/holding/etapas/1",
    },
    {
      icon: Users,
      title: "Análise do Patrimônio e Entrevista com os Sócios",
      description: "Realizamos um levantamento detalhado do seu patrimônio e entrevistamos todos os futuros sócios.",
      status: "completed" as const,
      step: 2,
      actionLink: "/dashboard/holding/etapas/2",
    },
    {
      icon: Building,
      title: "Escolha da Estrutura Jurídica e Tipo de Holding",
      description: "Definimos o modelo jurídico mais adequado para sua holding com base nos seus objetivos.",
      status: "current" as const,
      step: 3,
      actionLink: "/dashboard/holding/etapas/3",
      actionText: "Revisar Estrutura Proposta",
    },
    {
      icon: FileText,
      title: "Elaboração do Contrato Social",
      description: "Preparamos o contrato social com todas as cláusulas necessárias para proteger seu patrimônio.",
      status: "waiting" as const,
      step: 4,
      actionLink: "/dashboard/holding/etapas/4",
      waitingText: "Aguardando a conclusão da etapa anterior para iniciar a elaboração do contrato social.",
    },
    {
      icon: Scale,
      title: "Registro da Empresa (Junta Comercial e CNPJ)",
      description: "Realizamos todos os registros legais necessários para formalizar sua holding.",
      status: "pending" as const,
      step: 5,
      actionLink: "/dashboard/holding/etapas/5",
    },
    {
      icon: FileCheck,
      title: "Definição e Integralização do Capital Social",
      description: "Definimos o capital social e realizamos sua integralização conforme planejamento.",
      status: "pending" as const,
      step: 6,
      actionLink: "/dashboard/holding/etapas/6",
    },
    {
      icon: Receipt,
      title: "Cumprimento das Obrigações Fiscais",
      description: "Garantimos que todas as obrigações fiscais iniciais sejam cumpridas corretamente.",
      status: "pending" as const,
      step: 7,
      actionLink: "/dashboard/holding/etapas/7",
    },
    {
      icon: Home,
      title: "Transferência dos Bens para a Holding",
      description: "Realizamos a transferência legal de todos os bens para a estrutura da holding.",
      status: "pending" as const,
      step: 8,
      actionLink: "/dashboard/holding/etapas/8",
    },
    {
      icon: Shield,
      title: "Estabelecimento de Políticas de Governança",
      description: "Implementamos políticas de governança para a gestão eficiente da holding.",
      status: "pending" as const,
      step: 9,
      actionLink: "/dashboard/holding/etapas/9",
    },
    {
      icon: HeartPulse,
      title: "Acompanhamento e Assessoria Contínua",
      description: "Oferecemos suporte contínuo para garantir o funcionamento adequado da sua holding.",
      status: "pending" as const,
      step: 10,
      actionLink: "/dashboard/holding/etapas/10",
      isLast: true,
    },
  ]

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Constituição da Holding Patrimonial</h1>
          <p className="mt-2 text-xl text-gray-600">Acompanhe o progresso da criação da sua holding patrimonial</p>
        </div>
        <div className="mt-4 flex space-x-3 md:mt-0">
          <Link href="/dashboard/holding/documentos">
            <Button variant="outline" className="border-teal-400/30 text-teal-600 hover:bg-teal-50">
              <FileText className="mr-2 h-4 w-4" />
              Ver Documentos
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="col-span-3 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">Progresso da Constituição</h2>
            <div className="flex items-center gap-2 rounded-full bg-teal-100 px-3 py-1 text-sm font-medium text-teal-800">
              <span className="h-2 w-2 rounded-full bg-teal-500"></span>
              <span>30% Concluído</span>
            </div>
          </div>

          <div className="relative">
            <div className="mb-8 h-3 w-full rounded-full bg-gray-100">
              <div className="h-3 w-[30%] rounded-full bg-gradient-to-r from-teal-400 to-cyan-500"></div>
            </div>

            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>Início do Processo</span>
                <span>Conclusão</span>
              </div>
              <div className="flex justify-between">
                <span>15/03/2023</span>
                <span>Previsão: 30/06/2023</span>
              </div>
            </div>
          </div>
        </div>

        <div className="col-span-3 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-6 text-2xl font-bold text-gray-800">Linha do Tempo do Processo</h2>

          <div className="timeline-container">
            {etapas.map((etapa, index) => (
              <TimelineStep
                key={index}
                icon={etapa.icon}
                title={etapa.title}
                description={etapa.description}
                status={etapa.status}
                step={etapa.step}
                isLast={etapa.isLast}
                actionLink={etapa.actionLink}
                actionText={etapa.actionText}
                waitingText={etapa.waitingText}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-3">
        <div className="col-span-1 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-6 text-2xl font-bold text-gray-800">Próximas Ações</h2>

          <div className="space-y-4">
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4">
              <h3 className="flex items-center text-lg font-medium text-amber-800">
                <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-white">
                  !
                </span>
                Ação Necessária
              </h3>
              <p className="mt-2 text-gray-700">Revisar a proposta de estrutura jurídica para sua holding.</p>
              <Button className="mt-4 w-full bg-amber-500 text-white hover:bg-amber-600">Revisar Agora</Button>
            </div>

            <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
              <h3 className="text-lg font-medium text-gray-800">Próxima Reunião</h3>
              <p className="mt-2 text-gray-700">Reunião de alinhamento com o advogado responsável.</p>
              <div className="mt-3 flex items-center text-sm text-gray-600">
                <span className="mr-2">📅</span>
                <span>25 de Maio, 2023 - 14:00</span>
              </div>
            </div>
          </div>
        </div>

        <div className="col-span-2 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-6 text-2xl font-bold text-gray-800">Documentos Recentes</h2>

          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-lg bg-gray-50 p-4 hover:bg-gray-100 transition-colors">
              <div className="flex items-center">
                <div className="mr-4 rounded-md bg-teal-100 p-2">
                  <FileText className="h-6 w-6 text-teal-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-800">Contrato Social - Minuta</h3>
                  <p className="text-sm text-gray-600">Adicionado em 10/05/2023</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="border-teal-400 text-teal-600 hover:bg-teal-50">
                Visualizar
              </Button>
            </div>

            <div className="flex items-center justify-between rounded-lg bg-gray-50 p-4 hover:bg-gray-100 transition-colors">
              <div className="flex items-center">
                <div className="mr-4 rounded-md bg-amber-100 p-2">
                  <FileText className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-800">Análise Patrimonial</h3>
                  <p className="text-sm text-gray-600">Adicionado em 05/05/2023</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="border-amber-400 text-amber-600 hover:bg-amber-50">
                Visualizar
              </Button>
            </div>

            <div className="flex items-center justify-between rounded-lg bg-gray-50 p-4 hover:bg-gray-100 transition-colors">
              <div className="flex items-center">
                <div className="mr-4 rounded-md bg-blue-100 p-2">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-800">Planejamento Sucessório</h3>
                  <p className="text-sm text-gray-600">Adicionado em 01/05/2023</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="border-blue-400 text-blue-600 hover:bg-blue-50">
                Visualizar
              </Button>
            </div>
          </div>

          <div className="mt-4 text-center">
            <Link href="/dashboard/holding/documentos">
              <Button variant="ghost" className="text-teal-600 hover:text-teal-700 hover:bg-teal-50">
                Ver todos os documentos
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
