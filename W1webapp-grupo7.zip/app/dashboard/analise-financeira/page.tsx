"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Chart } from "@/components/dashboard/chart"
import { GraficosPatrimoniais } from "@/components/dashboard/graficos-patrimoniais"
import { AnaliseCenariosFiscais } from "@/components/dashboard/analise-cenarios-fiscais"

export default function AnaliseFinanceiraPage() {
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratação
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="space-y-6 pb-10">
      <div className="flex flex-col gap-2">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="w-full">
            <h1 className="text-2xl font-bold tracking-tight text-black">Análise Financeira</h1>
            <p className="text-black mt-1">Análise detalhada de indicadores financeiros e patrimoniais</p>
          </div>
        </div>
      </div>

      {/* Gráficos Patrimoniais */}
      <GraficosPatrimoniais className="animate-fade-in" style={{ animationDelay: "100ms" }} />

      {/* Análise de Cenários Fiscais */}
      <AnaliseCenariosFiscais className="animate-fade-in" style={{ animationDelay: "200ms" }} />

      <div className="grid gap-4 md:grid-cols-2">
        <Chart
          title="Receita Mensal"
          description="Análise de receita dos últimos 6 meses"
          chartType="line"
          height={300}
          className="animate-fade-in"
          style={{ animationDelay: "300ms" }}
        />
        <Chart
          title="Despesas por Categoria"
          description="Distribuição de despesas por categoria"
          chartType="pie"
          height={300}
          className="animate-fade-in"
          style={{ animationDelay: "400ms" }}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Chart
          title="Transações por Mês"
          description="Volume de transações nos últimos 6 meses"
          chartType="bar"
          height={300}
          className="md:col-span-2 animate-fade-in"
          style={{ animationDelay: "500ms" }}
        />

        <Card
          className="border border-gray-200 bg-white shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in"
          style={{ animationDelay: "600ms" }}
        >
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium text-gray-800">Indicadores Financeiros</CardTitle>
            <CardDescription className="text-gray-600">Principais KPIs financeiros</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-700">ROI</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-gray-900">24.5%</span>
                  <Badge className="bg-emerald-500/20 text-emerald-700 border-emerald-500/50">+5.2%</Badge>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-700">Margem Líquida</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-gray-900">18.3%</span>
                  <Badge className="bg-emerald-500/20 text-emerald-700 border-emerald-500/50">+2.1%</Badge>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-700">Liquidez Corrente</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-gray-900">2.4</span>
                  <Badge className="bg-emerald-500/20 text-emerald-700 border-emerald-500/50">+0.3</Badge>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-700">Endividamento</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-gray-900">32.7%</span>
                  <Badge className="bg-rose-500/20 text-rose-700 border-rose-500/50">+1.5%</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
