import type { Metadata } from "next"
import { Headphones, Bot, Clock, Users, MessageSquare } from "lucide-react"

import { AssistenteChatbot } from "@/components/assistente-chatbot"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Atendimento | W1 Holding Patrimonial",
  description:
    "Central de atendimento automatizado com IA para tirar suas dúvidas sobre o processo de constituição de holding patrimonial.",
}

export default function AtendimentoPage() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold tracking-tight">Atendimento</h1>
          <Badge variant="outline" className="bg-primary/10 text-primary">
            <Bot className="mr-1 h-3 w-3" />
            Com IA
          </Badge>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Headphones className="h-5 w-5" />
          <span className="text-sm">Central de Atendimento Automatizado</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <AssistenteChatbot />
        </div>

        <div className="lg:col-span-1">
          <Card className="h-full border-2 border-gray-200 bg-white shadow-lg text-gray-900 overflow-hidden">
            <CardHeader className="border-b border-gray-200">
              <CardTitle className="text-xl truncate">Precisa de ajuda?</CardTitle>
              <CardDescription className="text-gray-600 break-words">
                Nossos especialistas estão disponíveis para atendê-lo
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 py-4">
              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-200 bg-gray-50 overflow-hidden">
                <div className="bg-primary/10 p-2 rounded-full shrink-0">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-medium truncate">Horário de Atendimento</h3>
                  <p className="text-sm text-gray-600 break-words">Segunda a Sexta, das 9h às 18h</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-200 bg-gray-50 overflow-hidden">
                <div className="bg-primary/10 p-2 rounded-full shrink-0">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-medium truncate">Equipe Especializada</h3>
                  <p className="text-sm text-gray-600 break-words">
                    Advogados e consultores tributários à sua disposição
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-lg border border-gray-200 bg-gray-50 overflow-hidden">
                <div className="bg-primary/10 p-2 rounded-full shrink-0">
                  <MessageSquare className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-medium truncate">Contato Direto</h3>
                  <p className="text-sm text-gray-600 break-words">Telefone: +55 (11) 4301-7007</p>
                  <p className="text-sm text-gray-600 break-words">Email: relacionamento@w1consultoria.com.br</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full truncate"
                variant="outline"
                className="border-gray-300 bg-white hover:bg-gray-50 text-gray-900"
              >
                Agendar Reunião
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
