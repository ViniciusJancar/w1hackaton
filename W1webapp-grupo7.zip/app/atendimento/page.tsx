"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronRight, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AssistenteChatbot } from "@/components/assistente-chatbot"
import { ContextualHelp } from "@/components/contextual-help"

export default function AtendimentoPage() {
  const [showHelp, setShowHelp] = useState(false)

  return (
    <div className="w-full px-4 py-8 md:px-6 md:py-12">
      {/* Breadcrumb */}
      <div className="flex items-center text-sm text-gray-300 mb-6">
        <Link href="/" className="hover:text-teal-400 transition-colors">
          Início
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-gray-100">Atendimento</span>
      </div>

      {/* Cabeçalho da página */}
      <div className="mb-8">
        <div className="flex items-center gap-2">
          <h1 className="text-3xl font-bold text-gray-100 high-contrast-text mb-2">Atendimento Automatizado</h1>
          <ContextualHelp
            title="Sobre o Atendimento Automatizado"
            content="Este assistente virtual está disponível 24 horas por dia para responder suas dúvidas sobre o processo de constituição da sua holding patrimonial. Basta digitar sua pergunta no campo abaixo."
          />
        </div>
        <p className="text-gray-300 max-w-3xl text-large">
          Tire suas dúvidas sobre o processo de constituição da sua holding patrimonial com nosso assistente virtual.
        </p>
      </div>

      {/* Seção de Ajuda Rápida */}
      <div className="mb-8">
        <Button
          onClick={() => setShowHelp(!showHelp)}
          className="mb-4 bg-teal-600 hover:bg-teal-700 text-white flex items-center gap-2"
        >
          <HelpCircle className="h-5 w-5" />
          {showHelp ? "Ocultar ajuda" : "Precisa de ajuda para começar?"}
        </Button>

        {showHelp && (
          <Card className="bg-gray-900/50 border-gray-800/50 text-gray-100 mb-6">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4 text-teal-400">Como usar o assistente virtual</h3>
              <ul className="space-y-3 text-gray-200">
                <li className="flex items-start gap-2">
                  <span className="text-teal-400 font-bold">1.</span>
                  <span>Digite sua pergunta no campo de texto na parte inferior do chat.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-400 font-bold">2.</span>
                  <span>Clique no botão de enviar ou pressione Enter para enviar sua pergunta.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-400 font-bold">3.</span>
                  <span>Você também pode clicar em uma das perguntas sugeridas para começar rapidamente.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-400 font-bold">4.</span>
                  <span>O assistente responderá sua pergunta e poderá sugerir próximos passos.</span>
                </li>
              </ul>
              <div className="mt-4 p-3 bg-gray-800/50 rounded-lg border border-gray-700">
                <h4 className="font-medium text-teal-400 mb-2">Exemplos de perguntas que você pode fazer:</h4>
                <ul className="space-y-2 text-gray-200">
                  <li>• "Qual é o status atual do meu processo?"</li>
                  <li>• "Quais são as etapas para constituir uma holding?"</li>
                  <li>• "Quais documentos preciso enviar na próxima etapa?"</li>
                  <li>• "Quando será minha próxima reunião?"</li>
                  <li>• "Quais são os benefícios fiscais de uma holding?"</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Componente de Chatbot */}
      <AssistenteChatbot />
    </div>
  )
}
