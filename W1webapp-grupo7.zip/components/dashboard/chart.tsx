"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

// Paleta de cores com ordem de prioridade ajustada
const COLORS = {
  primary: "#009E73", // Verde (principal)
  secondary: "#56B4E9", // Azul claro (secundária)
  tertiary: "#E69F00", // Laranja (terciária)
  quaternary: "#F0E442", // Amarelo (quaternária)
  quinary: "#333333", // Cinza escuro (quinta)
  senary: "#CC79A7", // Rosa (sexta)
  darkBlue: "#0072B2", // Azul escuro (alternativa)
  darkOrange: "#D55E00", // Laranja escuro (alternativa)
  gray: "#999999", // Cinza (alternativa)
}

interface ChartProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string
  description?: string
  chartType: "line" | "bar" | "pie"
  height?: number
}

export function Chart({ title, description, chartType, height = 300, className, ...props }: ChartProps) {
  return (
    <Card
      className={cn("border border-gray-200 bg-white shadow-sm transition-all duration-300 hover:shadow-md", className)}
      {...props}
    >
      <CardHeader>
        <CardTitle className="text-lg font-medium text-gray-800">{title}</CardTitle>
        {description && <CardDescription className="text-gray-600">{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <div style={{ height: `${height}px` }}>
          {chartType === "line" && <LineChart />}
          {chartType === "bar" && <BarChartComponent />}
          {chartType === "pie" && <PieChartComponent />}
        </div>
      </CardContent>
    </Card>
  )
}

function LineChart() {
  const data = [
    { name: "Jan", valor: 12500 },
    { name: "Fev", valor: 18200 },
    { name: "Mar", valor: 15800 },
    { name: "Abr", valor: 22300 },
    { name: "Mai", valor: 28900 },
    { name: "Jun", valor: 32100 },
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={data}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis dataKey="name" stroke="#6B7280" />
        <YAxis stroke="#6B7280" tickFormatter={(value) => `R$ ${value / 1000}k`} />
        <Tooltip
          contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB", borderRadius: "0.375rem" }}
          itemStyle={{ color: "#1F2937" }}
          formatter={(value: number) => [`R$ ${value.toLocaleString()}`, "Receita"]}
        />
        <Area
          type="monotone"
          dataKey="valor"
          name="Receita"
          stroke={COLORS.primary}
          fill={COLORS.primary}
          fillOpacity={0.3}
          activeDot={{ r: 8 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  )
}

function BarChartComponent() {
  const data = [
    { name: "Jan", valor: 120 },
    { name: "Fev", valor: 145 },
    { name: "Mar", valor: 132 },
    { name: "Abr", valor: 178 },
    { name: "Mai", valor: 205 },
    { name: "Jun", valor: 226 },
  ]

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{
          top: 10,
          right: 30,
          left: 0,
          bottom: 0,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
        <XAxis dataKey="name" stroke="#6B7280" />
        <YAxis stroke="#6B7280" />
        <Tooltip
          contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB", borderRadius: "0.375rem" }}
          itemStyle={{ color: "#1F2937" }}
          formatter={(value: number) => [`${value}`, "Transações"]}
        />
        <Bar dataKey="valor" name="Transações" fill={COLORS.secondary} radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}

function PieChartComponent() {
  const data = [
    { name: "Operacional", valor: 35, color: COLORS.primary },
    { name: "Marketing", valor: 25, color: COLORS.secondary },
    { name: "Pessoal", valor: 30, color: COLORS.tertiary },
    { name: "Outros", valor: 10, color: COLORS.quaternary },
  ]

  const RADIAN = Math.PI / 180
  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    index,
  }: {
    cx: number
    cy: number
    midAngle: number
    innerRadius: number
    outerRadius: number
    percent: number
    index: number
  }) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5
    const x = cx + radius * Math.cos(-midAngle * RADIAN)
    const y = cy + radius * Math.sin(-midAngle * RADIAN)

    return (
      <text
        x={x}
        y={y}
        fill="#FFFFFF"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
        fontWeight="bold"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    )
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          label={renderCustomizedLabel}
          outerRadius={120}
          fill="#8884d8"
          dataKey="valor"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={{ backgroundColor: "#FFFFFF", borderColor: "#E5E7EB", borderRadius: "0.375rem" }}
          itemStyle={{ color: "#1F2937" }}
          formatter={(value: number) => [`${value}%`, "Percentual"]}
        />
        <Legend
          layout="horizontal"
          verticalAlign="bottom"
          align="center"
          formatter={(value, entry, index) => <span style={{ color: "#1F2937" }}>{value}</span>}
        />
      </PieChart>
    </ResponsiveContainer>
  )
}
