"use client"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"

// Dados para o gráfico
const economiaData = [
  {
    categoria: "Sucessão Patrimonial",
    semW1: 8.5, // Percentual sobre o patrimônio
    comW1: 2.1,
    economia: "75%",
    descricao: "Redução em impostos e custos de inventário",
  },
  {
    categoria: "Tributação Anual",
    semW1: 15.2,
    comW1: 9.8,
    economia: "35%",
    descricao: "Economia em impostos sobre rendimentos",
  },
  {
    categoria: "Venda de Ativos",
    semW1: 22.5,
    comW1: 12.3,
    economia: "45%",
    descricao: "Redução na tributação sobre ganho de capital",
  },
  {
    categoria: "Distribuição de Lucros",
    semW1: 17.8,
    comW1: 6.2,
    economia: "65%",
    descricao: "Economia na distribuição de dividendos",
  },
]

export function EconomiaRealChart() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  return (
    <div ref={ref} className="w-full">
      <div className="space-y-8">
        {economiaData.map((item, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-gray-900">{item.categoria}</h3>
                <p className="text-sm text-gray-600">{item.descricao}</p>
              </div>
              <div className="text-right">
                <span className="text-lg font-bold text-teal-600">{item.economia}</span>
                <p className="text-sm text-gray-600">de economia</p>
              </div>
            </div>

            <div className="relative h-10">
              {/* Barra "Sem W1" */}
              <div className="absolute top-0 left-0 h-5 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: inView ? `${item.semW1 * 4}%` : 0 }}
                  transition={{ duration: 1, delay: index * 0.2 }}
                  className="h-full bg-rose-500 rounded-full"
                />
              </div>

              {/* Barra "Com W1" */}
              <div className="absolute bottom-0 left-0 h-5 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: inView ? `${item.comW1 * 4}%` : 0 }}
                  transition={{ duration: 1, delay: index * 0.2 + 0.5 }}
                  className="h-full bg-teal-500 rounded-full"
                />
              </div>

              {/* Rótulos de percentual */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: inView ? 1 : 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 + 1 }}
                className="absolute top-0 h-5 flex items-center"
                style={{ left: `${item.semW1 * 4}%` }}
              >
                <span className="ml-2 text-xs font-medium text-gray-900">{item.semW1}%</span>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: inView ? 1 : 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 + 1 }}
                className="absolute bottom-0 h-5 flex items-center"
                style={{ left: `${item.comW1 * 4}%` }}
              >
                <span className="ml-2 text-xs font-medium text-gray-900">{item.comW1}%</span>
              </motion.div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <div className="flex items-start gap-3">
          <div className="rounded-full bg-teal-50 p-2 text-teal-600 mt-1">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-5 w-5"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M12 16v-4" />
              <path d="M12 8h.01" />
            </svg>
          </div>
          <div>
            <h4 className="font-medium text-gray-900">Como interpretar este gráfico</h4>
            <p className="text-sm text-gray-700 mt-1">
              Este gráfico mostra a comparação percentual da carga tributária em diferentes cenários, com e sem a
              estruturação patrimonial da W1. Os percentuais representam a proporção sobre o valor total do patrimônio
              ou transação.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
