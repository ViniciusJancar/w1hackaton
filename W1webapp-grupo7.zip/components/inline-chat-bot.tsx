"use client"

import { useState, useRef, useEffect } from "react"
import { Send, Bot, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"

type Message = {
  id: number
  sender: "user" | "bot"
  text: string
  timestamp: Date
}

type QuickReply = {
  id: string
  text: string
}

export function InlineChatBot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      sender: "bot",
      text: "Olá! Como posso ajudar com sua holding patrimonial hoje?",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const [shouldAutoScroll, setShouldAutoScroll] = useState(false)

  const quickReplies: QuickReply[] = [
    { id: "q1", text: "Quero proteger meu patrimônio familiar..." },
    { id: "q2", text: "Preciso reduzir a carga tributária..." },
    { id: "q3", text: "Tenho dúvidas sobre sucessão patrimonial..." },
    { id: "q4", text: "Quero criar uma holding para meus imóveis..." },
  ]

  // Função para buscar resposta da API da OpenAI
  const fetchAIResponse = async (messageHistory: Message[]) => {
    try {
      setIsLoading(true)

      // Converter mensagens para o formato esperado pela API
      const apiMessages = messageHistory.map((msg) => ({
        role: msg.sender === "user" ? "user" : "assistant",
        content: msg.text,
      }))

      // Fazer a chamada para a API
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: apiMessages,
        }),
      })

      if (!response.ok) {
        throw new Error(`Erro na API: ${response.status}`)
      }

      const data = await response.json()

      // Verificar se a resposta contém o campo esperado
      if (!data.response) {
        throw new Error("Formato de resposta inválido")
      }

      return data.response
    } catch (error) {
      console.error("Erro ao processar mensagem:", error)
      return "Desculpe, estou com dificuldades para processar sua solicitação no momento. Por favor, tente novamente ou entre em contato com nosso suporte pelo telefone +55 (11) 4301-7007 ou email relacionamento@w1consultoria.com.br."
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return

    // Adiciona mensagem do usuário
    const userMessage: Message = {
      id: Date.now(),
      sender: "user",
      text: inputValue,
      timestamp: new Date(),
    }

    const updatedMessages = [...messages, userMessage]
    setMessages(updatedMessages)
    setInputValue("")

    // Ativa a rolagem automática apenas para mensagens do usuário
    setShouldAutoScroll(true)

    // Obtém resposta da IA
    const aiResponse = await fetchAIResponse(updatedMessages)

    // Adiciona resposta do bot
    const botResponse: Message = {
      id: Date.now() + 1,
      sender: "bot",
      text: aiResponse,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, botResponse])

    // Desativa a rolagem automática para respostas do bot
    setShouldAutoScroll(false)
  }

  const handleQuickReply = (text: string) => {
    if (isLoading) return
    setInputValue(text)
    handleSendMessage()
  }

  // Manipulador de evento de rolagem
  const handleScroll = () => {
    if (!scrollAreaRef.current) return

    const { scrollTop, scrollHeight, clientHeight } = scrollAreaRef.current
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight

    // Se o usuário estiver próximo do final, permitir rolagem automática
    if (distanceFromBottom < 100) {
      setShouldAutoScroll(true)
    }
  }

  // Rola para a última mensagem apenas quando shouldAutoScroll for true
  useEffect(() => {
    if (shouldAutoScroll) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
      setShouldAutoScroll(false)
    }
  }, [messages, shouldAutoScroll])

  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-black mb-2">Análise Preliminar de Casos</h2>
        <p className="text-black text-lg max-w-3xl mx-auto">
          Descreva sua situação patrimonial para nosso assistente virtual e receba uma análise preliminar para verificar
          como podemos ajudar
        </p>
      </div>

      <div className="bg-white border border-gray-300 rounded-lg overflow-hidden shadow-xl">
        <div className="bg-gray-100 border-b border-gray-300 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-teal-500" />
              <h3 className="text-xl font-semibold text-gray-900">Assistente Virtual W1</h3>
            </div>
          </div>
        </div>

        <div className="p-6">
          <ScrollArea className="h-[500px]" ref={scrollAreaRef} onScroll={handleScroll}>
            <div className="space-y-6">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[85%] rounded-lg p-4 ${
                      message.sender === "user"
                        ? "bg-teal-600 text-white"
                        : "bg-gray-100 text-gray-900 border border-gray-300"
                    }`}
                  >
                    {message.sender === "bot" && (
                      <div className="flex items-center mb-2">
                        <div className="w-8 h-8 mr-2 flex items-center justify-center rounded-full bg-teal-600 shrink-0">
                          <Bot className="h-5 w-5 text-white" />
                        </div>
                        <span className="font-medium text-teal-400">Assistente W1</span>
                      </div>
                    )}
                    <p className="text-lg">{message.text}</p>
                    <p className="mt-2 text-sm opacity-70">
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] rounded-lg p-4 bg-[#0F1824] border border-gray-800">
                    <div className="flex items-center mb-2">
                      <div className="w-8 h-8 mr-2 flex items-center justify-center rounded-full bg-teal-600 shrink-0">
                        <Bot className="h-5 w-5 text-white" />
                      </div>
                      <span className="font-medium text-teal-400">Assistente W1</span>
                    </div>
                    <div className="flex space-x-2">
                      <div className="h-3 w-3 rounded-full bg-teal-400 animate-bounce" />
                      <div
                        className="h-3 w-3 rounded-full bg-teal-400 animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      />
                      <div
                        className="h-3 w-3 rounded-full bg-teal-400 animate-bounce"
                        style={{ animationDelay: "0.4s" }}
                      />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          <div className="border-t border-gray-300 pt-6 mt-6">
            <div className="text-base text-black mb-3">Exemplos de casos que podemos analisar:</div>
            <div className="flex flex-wrap gap-3">
              {quickReplies.map((reply) => (
                <button
                  key={reply.id}
                  onClick={() => handleQuickReply(reply.text)}
                  className="rounded-md border border-gray-300 px-4 py-3 text-base text-gray-900 hover:bg-gray-100 transition-colors bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  disabled={isLoading}
                >
                  {reply.text}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-6">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSendMessage()
              }}
              className="flex w-full items-center gap-3"
            >
              <div className="flex-1 relative">
                <Input
                  type="text"
                  placeholder="Descreva sua situação patrimonial aqui..."
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 text-gray-900 placeholder:text-gray-500 focus:border-teal-500 focus:outline-none"
                  disabled={isLoading}
                />
              </div>
              <Button
                type="submit"
                disabled={!inputValue.trim() || isLoading}
                className="bg-teal-600 text-white hover:bg-teal-700"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                    Enviando...
                  </span>
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </Button>
            </form>
          </div>
        </div>

        <div className="border-t border-gray-300 p-4 bg-gray-100 text-center">
          <p className="text-sm text-gray-700">
            Este assistente virtual fornece apenas uma análise preliminar. Para um planejamento patrimonial completo,
            recomendamos uma consultoria personalizada com nossos especialistas.
          </p>
        </div>
      </div>
    </div>
  )
}
