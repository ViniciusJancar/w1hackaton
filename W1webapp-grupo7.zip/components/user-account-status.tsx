"use client"

import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useState, useEffect } from "react"

export function UserAccountStatus() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const timer = setTimeout(() => setProgress(80), 500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="hidden">
      {/* This component is now hidden but preserved in case it needs to be restored later */}
      <Card className="bg-gray-900 p-4 rounded-lg shadow-md">
        <div className="flex items-center gap-3">
          <div className="bg-teal-500 rounded-full w-10 h-10 flex items-center justify-center text-white font-bold">
            W1
          </div>
          <div>
            <h4 className="text-white font-medium">W1 Pro</h4>
            <p className="text-gray-400 text-sm">Acesso completo</p>
          </div>
        </div>
        <div className="mt-3">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Uso do plano</span>
            <span className="text-white font-medium">{progress}%</span>
          </div>
          <Progress value={progress} className="h-1.5 bg-gray-700" indicatorClassName="bg-teal-500" />
        </div>
      </Card>
    </div>
  )
}
