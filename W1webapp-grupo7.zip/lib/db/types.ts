/**
 * Tipos para as entidades do banco de dados
 *
 * Este arquivo contém as interfaces TypeScript para as entidades do sistema.
 * Adicione ou modifique conforme necessário.
 */

// Usuário
export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "client" | "manager"
  createdAt: Date
  updatedAt: Date
}

// Holding
export interface Holding {
  id: string
  name: string
  cnpj: string
  userId: string
  status: "active" | "pending" | "inactive"
  createdAt: Date
  updatedAt: Date
}

// Empresa
export interface Company {
  id: string
  name: string
  cnpj: string
  holdingId: string
  type: "ltda" | "sa" | "mei" | "ei" | "other"
  createdAt: Date
  updatedAt: Date
}

// Documento
export interface Document {
  id: string
  name: string
  type: "contrato" | "procuracao" | "certidao" | "outro"
  status: "pending" | "approved" | "rejected"
  url: string
  holdingId: string
  userId: string
  createdAt: Date
  updatedAt: Date
}

// Processo
export interface Process {
  id: string
  title: string
  description: string
  status: "not_started" | "in_progress" | "completed" | "blocked"
  holdingId: string
  currentStepId: string
  createdAt: Date
  updatedAt: Date
}

// Etapa do Processo
export interface ProcessStep {
  id: string
  title: string
  description: string
  order: number
  status: "not_started" | "in_progress" | "completed" | "blocked"
  processId: string
  createdAt: Date
  updatedAt: Date
}

// Transação Financeira
export interface Transaction {
  id: string
  description: string
  amount: number
  type: "income" | "expense"
  category: string
  date: Date
  userId: string
  holdingId?: string
  companyId?: string
  createdAt: Date
  updatedAt: Date
}

// Análise Financeira
export interface FinancialAnalysis {
  id: string
  title: string
  description: string
  data: any // Estrutura de dados para análise
  userId: string
  holdingId?: string
  createdAt: Date
  updatedAt: Date
}

// Notificação
export interface Notification {
  id: string
  title: string
  message: string
  read: boolean
  type: "info" | "warning" | "error" | "success"
  userId: string
  createdAt: Date
}
